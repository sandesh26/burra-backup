require 'sidekiq/web'

Rails.application.routes.draw do
  mount Sidekiq::Web => "/sidekiq"
  # mount ActionCable.server => '/cable'
  root to: 'dashboard#index'
  devise_for :users
  get "up" => "rails/health#show", as: :rails_health_check
  get "audits" => "audits#index"

  resources :vendors
  resources :activity_categories
  resources :activities do
    collection do
      get 'pending'
    end
    member do
      get 'activate'
    end
  end

  post 'payments/success'

  resources :admin_users
  resources :roles
  resources :customers, only: [:index] do
    resources :wishlists, only: [:index, :show]
    resources :carts, only: [:show]
  end
  resources :locations do
    member  do
      get 'activate'
    end
  end
  resources :wallets, except: [:destroy, :create, :new] do
    collection do
      get :vendors
      get :customers
    end
    member do
      get 'transactions'
    end
  end
  resources :coupons
  resources :reviews
  resources :blogs do
    collection do
      get 'inactive'
    end
  end
  resources :app_versions
  resources :blog_categories
  resources :complaints, only: [:index, :show, :update]
  resources :bookings, only: [:index, :show] do
    collection do
      post :success
      get :download, defaults: { format: :xlsx }
    end
    member do
      put :cancel
      get :resend_booking_confirmation_email
    end
  end
  resources :privacy_policies, only: [:index, :edit, :update]
  resources :cancellation_policies, only: [:index, :edit, :update]
  resources :terms_and_conditions, only: [:index, :edit, :update]
  resources :cancelations, only: [:index, :update, :show]
  resources :app_notifications, except: [:destroy]
  resources :refunds, only: [:index]
  resources :deep_links

  # RESTful api's
  namespace :api do
    namespace :v1 do
      post 'get_otp' => 'authentication#generate_otp'
      post 'sync_device_token' => 'authentication#sync_device_token' ## Common
      post 'auth_user' => 'authentication#authenticate_user' ## For vendors
      post 'sign_up' => 'authentication#sign_up' ## For customers
      post 'sign_in' => 'authentication#sign_in' ## For customers
      post 'forgot' => 'authentication#forgot' ## For customers
      post 'change_password' => 'authentication#change_password' ## For customers
      namespace :vendor do
        get 'listing_categories' => 'listings#categories'
        post 'upload_files' => 'listings#upload_files'
        # resources :listings, except: [:destroy] do
        #   # resources :cars, only: [:index, :update]
        #   # resources :rooms, only: [:index, :update]
          
        # end
        resources :app_versions, only: :index
        resources :activities, except: [:destroy] do
          member do
            put :pause
            put :toggle_prior_booking
          end
        end
        resources :bookings, only: [:index] do
          member do
            get :order_details
          end
        end
        resources :bank_accounts, only: [:index, :update] do
          collection do
            get :lists
          end
        end
        resources :profiles, only: [:update] do
          collection do
            delete :delete_account
          end
        end
        get 'earnings' => 'bookings#earnings'
        get 'activity_types' => 'entity_types#activity_types'
        # get 'car_features' => 'entity_types#car_features'
        # get 'room_dependents' => 'entity_types#room_dependents'
      end

      namespace :customer do
        resources :blogs, only: [:index, :show] do
          collection do
            get :categories
          end
        end
        resources :package_types, only: [:index]
        resources :app_versions, only: :index
        get 'coupons' => 'coupons#index'
        resources :coupons, only: [:index, :show] do
          collection do
            get :verify_coupon
          end
        end
        resources :users, only: [] do
          collection do
            get :wallet
            get :bookings
            get :request_otp
            post :add_review
            get :reviews
            delete :delete_account
          end
          member do
            put :update
          end
        end
        get 'bookings/:order_id' => 'users#order_details'
        get 'bookings/:order_id/cancel_request' => 'users#cancel_request'
        get 'bookings/:order_id/resend_booking_confirmation_email' => 'users#resend_booking_confirmation_email'
        resources :content, only: [] do
          collection do
            get :policy
            get :terms
            get :refund_policy
          end
        end

        resources :dashboard, only: [] do
          collection do
            get :top_destinations
            get :top_activities
            get :activity_categories
            get :categories_all
          end
        end
        resources :activities, only: [:index, :show] do
          collection do
            get :ratings
            get :my_rating
            post :add_rating
            get :similar
            get :events
          end
        end
        get 'activities/:id' => 'listings#activity_details'
        resources :carts, only: [:index, :create, :destroy] do
          collection do
            get :items
            post :checkout
            get :item_available
            post :razorpay_order_id
            post :initiate_payment
          end
        end
        resources :wishlists, only: [:index, :create, :destroy]
      end
    end

    namespace :v2 do
      namespace :customer do
        resources :carts, only: [:create, :destroy] do
          collection do
            get :items
            get :item_available
          end
        end
      end
    end
  end
end
