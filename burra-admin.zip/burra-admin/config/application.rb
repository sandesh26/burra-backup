require_relative "boot"
# require "active_storage/engine"
require "rails/all"

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module BurraAdmin
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 7.1

    # Please, add to the `ignore` list any other `lib` subdirectories that do
    # not contain `.rb` files, or that should not be reloaded or eager loaded.
    # Common ones are `templates`, `generators`, or `middleware`, for example.
    config.assets.enabled = true
    config.autoload_lib(ignore: %w(assets tasks))
    config.active_record.yaml_column_permitte
    d_classes = [Symbol, Date, Time, BigDecimal, ActiveSupport::TimeWithZone, ActiveSupport::TimeZone]
    config.hosts << /.*\.burraa\.com/
    # config.action_controller.forgery_protection_origin_check = false


    config.active_storage.routes_prefix = '/nebula'
    # config.cache_store = :redis_store, 'redis://localhost:6379/0/cache', { expires_in: 90.minutes }
    config.active_job.queue_adapter = :sidekiq
    # Configuration for the application, engines, and railties goes here.
    #
    # These settings can be overridden in specific environments using the files
    # in config/environments, which are processed later.
    #
    config.time_zone = "Kolkata"
    # config.eager_load_paths << Rails.root.join("extras")
    # config.middleware.insert_before 0, Rack::Cors do
    #   allow do
    #     origins "http://localhost:3001, http://localhost:3000"

    #     resource "*",
    #     headers: :any,
    #     methods: [:get, :post, :put, :patch, :delete, :options, :head], credentials: true
    #   end
    # end
  end
end
