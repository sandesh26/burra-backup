config = YAML.load_file('config/sidekiq.yml')[Rails.env]
Sidekiq.configure_server do |s|
  s.redis = { url: ENV['REDIS_URL'], password: ENV['REDIS_PASSWORD'] }
end
