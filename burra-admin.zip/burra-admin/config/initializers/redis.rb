# config/initializers/redis.rb

require 'redis'

# Create a Redis connection and assign it to a constant for use throughout the application
REDIS = Redis.new(url: ENV['REDIS_URL'] || 'redis://localhost:6379/0')