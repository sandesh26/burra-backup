require "test_helper"

class PrivacyPoliciesControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get privacy_policies_index_url
    assert_response :success
  end

  test "should get edit" do
    get privacy_policies_edit_url
    assert_response :success
  end

  test "should get update" do
    get privacy_policies_update_url
    assert_response :success
  end
end
