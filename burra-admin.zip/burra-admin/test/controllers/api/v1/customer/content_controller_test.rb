require "test_helper"

class Api::V1::Customer::ContentControllerTest < ActionDispatch::IntegrationTest
  test "should get terms" do
    get api_v1_customer_content_terms_url
    assert_response :success
  end

  test "should get policy" do
    get api_v1_customer_content_policy_url
    assert_response :success
  end
end
