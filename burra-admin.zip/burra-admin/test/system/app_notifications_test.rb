require "application_system_test_case"

class AppNotificationsTest < ApplicationSystemTestCase
  setup do
    @app_notification = app_notifications(:one)
  end

  test "visiting the index" do
    visit app_notifications_url
    assert_selector "h1", text: "App notifications"
  end

  test "should create app notification" do
    visit app_notifications_url
    click_on "New app notification"

    fill_in "Body", with: @app_notification.body
    fill_in "Click action", with: @app_notification.click_action
    fill_in "Click", with: @app_notification.click_id
    fill_in "Client ids", with: @app_notification.client_ids
    fill_in "Client type", with: @app_notification.client_type
    fill_in "Scheduled at", with: @app_notification.scheduled_at
    fill_in "Title", with: @app_notification.title
    click_on "Create App notification"

    assert_text "App notification was successfully created"
    click_on "Back"
  end

  test "should update App notification" do
    visit app_notification_url(@app_notification)
    click_on "Edit this app notification", match: :first

    fill_in "Body", with: @app_notification.body
    fill_in "Click action", with: @app_notification.click_action
    fill_in "Click", with: @app_notification.click_id
    fill_in "Client ids", with: @app_notification.client_ids
    fill_in "Client type", with: @app_notification.client_type
    fill_in "Scheduled at", with: @app_notification.scheduled_at
    fill_in "Title", with: @app_notification.title
    click_on "Update App notification"

    assert_text "App notification was successfully updated"
    click_on "Back"
  end

  test "should destroy App notification" do
    visit app_notification_url(@app_notification)
    click_on "Destroy this app notification", match: :first

    assert_text "App notification was successfully destroyed"
  end
end
