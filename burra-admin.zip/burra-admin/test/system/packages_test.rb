require "application_system_test_case"

class PackagesTest < ApplicationSystemTestCase
  setup do
    @package = packages(:one)
  end

  test "visiting the index" do
    visit packages_url
    assert_selector "h1", text: "Packages"
  end

  test "should create package" do
    visit packages_url
    click_on "New package"

    fill_in "Entity", with: @package.entity
    fill_in "Extras", with: @package.extras
    fill_in "Price", with: @package.price
    fill_in "Short description", with: @package.short_description
    fill_in "Slots", with: @package.slots
    fill_in "Title", with: @package.title
    click_on "Create Package"

    assert_text "Package was successfully created"
    click_on "Back"
  end

  test "should update Package" do
    visit package_url(@package)
    click_on "Edit this package", match: :first

    fill_in "Entity", with: @package.entity
    fill_in "Extras", with: @package.extras
    fill_in "Price", with: @package.price
    fill_in "Short description", with: @package.short_description
    fill_in "Slots", with: @package.slots
    fill_in "Title", with: @package.title
    click_on "Update Package"

    assert_text "Package was successfully updated"
    click_on "Back"
  end

  test "should destroy Package" do
    visit package_url(@package)
    click_on "Destroy this package", match: :first

    assert_text "Package was successfully destroyed"
  end
end
