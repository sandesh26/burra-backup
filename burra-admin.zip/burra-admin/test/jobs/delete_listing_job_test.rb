require "test_helper"

class DeleteListingJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
