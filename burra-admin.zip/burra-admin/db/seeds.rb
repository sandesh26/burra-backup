# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end

require 'faker'

["super_admin", "admin"].each do |role_name|
  role = Role.find_or_create_by(name: role_name)
  User.create(email: "#{role_name}@burraa.com", password: "#{role_name}#2024", password_confirmation: "#{role_name}#2024", role_id: role.id)
end

["Homestays", "Activities", "Renting Vehicles"].each do |category|
  ListingCategory.create(name: category)
end

["Bachelor", "Pets", "Smoking", "Unmarried", "Drinks"].each do |name|
  HouseRule.create(name: name)
end

["Sea Facing", "Mountains", "Beaches", "In The Mountains"].each do |name|
  HouseCategory.create(name: name)
end

["Apartment", "Resort", "Villa", "House", "Cottage"].each do |name|
  PropertyType.create(name: name)
end

["Housekeeping", "Laundry", "Wi-Fi", "Room Service", "Swiming Pool", "Bonfire", "Spa", "Work Desk", "TV", "Newspaper"].each do |name|
  Amenity.create(name: name)
end

["6 Seater", "4 Seater", "11 Seater"].each do |name|
  CarSeat.create(name: name)
end

["Petrol", "Diesel", "CNG"].each do |name|
  CarFuelType.create(name: name)
end

["Hatchback", "Convertible", "Sedan", "Crossover", "Minivan"].each do |name|
  CarType.create(name: name)
end

["Automatic", "Manual"].each do |name|
  CarTransmission.create(name: name)
end

["Adventure", "Romantic", "In the woods", "Casino", "Sports", "Weekend trips", "Amusement park", "Concerts"].each do |name|
  ActivityCategory.create(name: name)
end

10.times do
  Customer.create(first_name: Faker::Name.first_name, last_name: Faker::Name.last_name, phone: Faker::PhoneNumber.cell_phone, email: (Faker::Name.name+'@gmail.com').split(' ').join().downcase)
end

10.times do
  Vendor.create(first_name: Faker::Name.first_name, middle_name: Faker::Name.middle_name, last_name: Faker::Name.last_name, phone: Faker::Number.number(digits: 10), email: (Faker::Name.name+'@gmail.com').split(' ').join().downcase)
end

12.times do
  blog_cat = BlogCategory.create(title: Faker::Sport.sport)
  Blog.create(title: Faker::Sport.winter_paralympics_sport, description: Faker::Lorem.paragraph_by_chars(number: 200, supplemental: true), blog_category_id: blog_cat.id)
end


# 5.times do
#   Booking.create(vendor_id: Vendor.find_by(phone: '8130950367').id, customer_id: Customer.last.id, order_id: "HHKHK87686", entity: Room.last, listing_amount: 5000, total_amt: 5000, from_date: Date.today, to_date: Date.today + 10.days)
# end

# 5.times do
#   Booking.create(vendor_id: Vendor.find_by(phone: '8130950367').id, customer_id: Customer.last.id, order_id: "HHKHK87686", entity: Room.last, listing_amount: 5000, total_amt: 5000, from_date: Date.today, to_date: Date.today - 10.days)
# end

# 5.times do
#   Booking.create(vendor_id: Vendor.find_by(phone: '8130950367').id, customer_id: Customer.last.id, order_id: "HHKHK87686", entity: Room.last, listing_amount: 5000, total_amt: 5000, from_date: Date.today, to_date: Date.today + 10.days, status: 'cancelled')
# end








