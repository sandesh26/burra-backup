class CreateCarTransmissions < ActiveRecord::Migration[7.1]
  def change
    create_table :car_transmissions do |t|
      t.string :name
      t.boolean :status, null: false, default: true

      t.timestamps
    end
  end
end
