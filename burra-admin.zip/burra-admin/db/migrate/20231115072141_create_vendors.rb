class CreateVendors < ActiveRecord::Migration[7.1]
  def change
    create_table :vendors do |t|
      t.string :first_name
      t.string :middle_name
      t.string :last_name
      t.string :phone
      t.string :email
      t.string :verification_code
      t.string :document_type
      t.string :status, null: false, default: "created"

      t.timestamps
    end
  end
end
