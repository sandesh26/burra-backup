class AddPackageTypeIdToItems < ActiveRecord::Migration[7.1]
  def change
    add_column :items, :package_type_id, :integer
  end
end
