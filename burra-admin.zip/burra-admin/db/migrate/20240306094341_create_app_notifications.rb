class CreateAppNotifications < ActiveRecord::Migration[7.1]
  def change
    create_table :app_notifications do |t|
      t.string :title, null: false, default: ''
      t.text :body, null: false, default: ''
      t.string :client_type, null: false, default: ''
      t.datetime :scheduled_at
      t.text :client_ids, array: true, default: []
      t.string :click_action, null: false, default: ''
      t.string :click_id, null: false, default: ''

      t.timestamps
    end
  end
end
