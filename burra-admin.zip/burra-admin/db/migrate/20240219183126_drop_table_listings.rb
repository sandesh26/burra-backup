class DropTableListings < ActiveRecord::Migration[7.1]
  def change
    drop_table :listings, force: :cascade
  end
end
