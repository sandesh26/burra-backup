class CreateCoupons < ActiveRecord::Migration[7.1]
  def change
    create_table :coupons do |t|
      t.string :title
      t.string :description
      t.integer :min_cart_val
      t.string :coupon_code
      t.date :valid_from
      t.date :valid_till
      t.boolean :status, null: false, default: true
      t.integer :customer_id
      t.boolean :common, null: false, default: true
      t.references :entity, polymorphic: true

      t.timestamps
    end
  end
end
