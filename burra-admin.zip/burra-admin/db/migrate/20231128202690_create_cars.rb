class CreateCars < ActiveRecord::Migration[7.1]
  def change
    create_table :cars do |t|
      t.string :name
      t.string :description
      t.integer :car_type_id
      t.integer :car_seat_id
      t.integer :car_fuel_type_id
      t.integer :car_transmission_id
      t.integer :discounted_price
      t.integer :actual_price
      t.references :listing, null: false, foreign_key: true
      t.boolean :is_deleted, null: false, default: false
      t.boolean :locked, null: false, default: false
      t.string :status, null: false, default: 'created'

      t.timestamps
    end
  end
end