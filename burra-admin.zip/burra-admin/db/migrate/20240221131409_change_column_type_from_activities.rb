class ChangeColumnTypeFromActivities < ActiveRecord::Migration[7.1]
  def change
    remove_column :activities, :prior_booking
    add_column :activities, :prior_booking, :boolean, null: false, default: false
  end
end
