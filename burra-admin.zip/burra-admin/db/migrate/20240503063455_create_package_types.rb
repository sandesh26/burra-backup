class CreatePackageTypes < ActiveRecord::Migration[7.1]
  def change
    create_table :package_types do |t|
      t.string :title, null: false, default: ''
      t.text :details, null: false, default: ''
      t.float :price, null: false, default: 0.0
      t.float :vendor_price, null: false, default: 0.0
      t.float :offer_price, null: false, default: 0.0
      t.boolean :customized_slots, null: false, default: false
      t.integer :package_id

      t.timestamps
    end
  end
end
