class AddAdditionalInfoToBookings < ActiveRecord::Migration[7.1]
  def change
    add_column :bookings, :additional_info, :jsonb
  end
end
