class CreateCancellationPolicies < ActiveRecord::Migration[7.1]
  def change
    create_table :cancellation_policies do |t|
      t.string :content

      t.timestamps
    end
  end
end
