class CreatePackages < ActiveRecord::Migration[7.1]
  def change
    create_table :packages do |t|
      t.string :title, null: false, default: ''
      t.text :details, null: false, default: ''
      t.references :entity, polymorphic: true, null: false

      t.timestamps
    end
  end
end
