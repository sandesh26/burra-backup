class CreateRooms < ActiveRecord::Migration[7.1]
  def change
    create_table :rooms do |t|
      t.integer :bedrooms
      t.integer :bathrooms
      t.integer :balcony
      t.string  :type_of_bed
      t.integer :min_guest_occupancy
      t.integer :max_guest_occupancy
      t.string  :name
      t.string  :description
      t.string :size
      t.integer :discounted_price
      t.integer :actual_price
      t.string  :floor_level
      t.references :listing, null: false, foreign_key: true
      t.string :house_rules, array: true, default: []
      t.integer :house_category_id
      t.integer :property_type_id
      t.string :amenities, array: true, default: []
      t.boolean :is_deleted, null: false, default: false
      t.boolean :locked, null: false, default: false
      t.string :status, null: false, default: 'created'

      t.timestamps
    end
  end
end