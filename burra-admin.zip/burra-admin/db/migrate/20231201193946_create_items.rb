class CreateItems < ActiveRecord::Migration[7.1]
  def change
    create_table :items do |t|
      t.references :cart, null: false, foreign_key: true
      t.references :entity, polymorphic: true, null: false
      t.date :selected_date

      t.timestamps
    end
  end
end
