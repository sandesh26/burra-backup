class CreateActivityCategories < ActiveRecord::Migration[7.1]
  def change
    create_table :activity_categories do |t|
      t.string :name
      t.boolean :status, null: false, default: true

      t.timestamps
    end
  end
end
