class CreateDeviceTokens < ActiveRecord::Migration[7.1]
  def change
    create_table :device_tokens do |t|
      t.string :token
      t.references :client, polymorphic: true

      t.timestamps
    end
  end
end