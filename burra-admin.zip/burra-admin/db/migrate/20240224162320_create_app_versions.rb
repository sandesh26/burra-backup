class CreateAppVersions < ActiveRecord::Migration[7.1]
  def change
    create_table :app_versions do |t|
      t.string :app_name, null: false, default: ''
      t.string :ios_version, null: false, default: ''
      t.string :android_version, null: false, default: ''
      t.boolean :force_update, null: false, default: false

      t.timestamps
    end
  end
end
