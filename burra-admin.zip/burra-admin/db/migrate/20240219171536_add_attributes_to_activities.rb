class AddAttributesToActivities < ActiveRecord::Migration[7.1]
  def change
    add_column :activities, :meta_title, :string
    add_column :activities, :meta_description, :string
    add_column :activities, :meta_keywords, :string
    add_column :activities, :address, :string
    add_column :activities, :latitude, :decimal, precision: 10, scale: 6
    add_column :activities, :longitude, :decimal, precision: 10, scale: 6
    add_reference :activities, :vendor, index: true, foreign_key: true
    add_column :activities, :account_detail_id, :integer
    add_column :activities, :location_id, :integer
    add_column :activities, :prior_booking, :boolean, null: false, default: false
  end
end