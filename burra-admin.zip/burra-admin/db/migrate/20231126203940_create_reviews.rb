class CreateReviews < ActiveRecord::Migration[7.1]
  def change
    create_table :reviews do |t|
      t.text :comment
      t.references :entity, polymorphic: true, null: false
      t.string :customer, null: false, default: ''
      t.integer :star
      t.integer :order_id
      t.boolean :is_approved, null: false, default: false

      t.timestamps
    end
  end
end
