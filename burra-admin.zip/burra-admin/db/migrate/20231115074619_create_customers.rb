class CreateCustomers < ActiveRecord::Migration[7.1]
  def change
    create_table :customers do |t|
      t.string :first_name
      t.string :last_name
      t.string :phone
      t.string :email
      t.string :social
      t.string :password
      t.string :verification_code
      t.string :status, null: false, default: "active"

      t.timestamps
    end
  end
end
