class AddDocumentTypeToVendor < ActiveRecord::Migration[7.1]
  def change
    add_column :vendors, :document_type, :string
  end
end
