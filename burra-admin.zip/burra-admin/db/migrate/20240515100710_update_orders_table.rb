class UpdateOrdersTable < ActiveRecord::Migration[7.1]
  def change
    remove_column :orders, :children
    remove_column :orders, :adults
    remove_column :orders, :notes
    remove_column :orders, :check_in_time
    remove_column :orders, :listing_amt
    remove_column :orders, :slots
  end
end
