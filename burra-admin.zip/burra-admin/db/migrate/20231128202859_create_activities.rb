class CreateActivities < ActiveRecord::Migration[7.1]
  def change
    create_table :activities do |t|
      t.string  :name
      t.string  :description
      t.integer :min_person_allowed
      t.integer :max_person_allowed
      t.integer :discounted_price
      t.integer :actual_price
      t.date :start_date
      t.string :start_time
      t.string :end_time
      t.string :meta_title
      t.string :meta_description
      t.string :meta_keywords
      t.decimal :latitude, precision: 10, scale: 6
      t.decimal :longitude, precision: 10, scale: 6
      t.string  :address
      t.references :vendor, null: false, foreign_key: true
      t.boolean :booking_paused, null: false, default: false
      t.date :booking_paused_until
      t.integer :activity_category_id
      t.boolean :is_deleted, null: false, default: false
      t.boolean :locked, null: false, default: false
      t.string :status, null: false, default: 'created'
      t.boolean :prior_booking, null: false, default: true

      t.timestamps
    end
  end
end
