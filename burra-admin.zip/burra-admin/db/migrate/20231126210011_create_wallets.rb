class CreateWallets < ActiveRecord::Migration[7.1]
  def change
    create_table :wallets do |t|
      t.references :entity, polymorphic: true, null: false
      t.integer :balance

      t.timestamps
    end
  end
end
