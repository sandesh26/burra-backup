class CreateComplaints < ActiveRecord::Migration[7.1]
  def change
    create_table :complaints do |t|
      t.string :title
      t.text :description
      t.string :status, null: false, default: 'open'
      t.references :customer, null: false, foreign_key: true
      t.string :reference_no
      t.integer :updated_by_id
      t.references :entity, polymorphic: true, null: false

      t.timestamps
    end
  end
end
