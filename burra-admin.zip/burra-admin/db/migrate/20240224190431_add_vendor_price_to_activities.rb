class AddVendorPriceToActivities < ActiveRecord::Migration[7.1]
  def change
    add_column :activities, :vendor_price, :integer
  end
end
