class CreateAccountDetails < ActiveRecord::Migration[7.1]
  def change
    create_table :account_details do |t|
      t.string :acc_holder_name
      t.string :branch_name
      t.string :email_id
      t.string :phone_number
      t.string :gst_number
      t.string :account_number
      t.string :ifsc_code
      t.string :bank_name
      t.references :vendor, null: false, foreign_key: true

      t.timestamps
    end
  end
end
