class CreateCancelations < ActiveRecord::Migration[7.1]
  def change
    create_table :cancelations do |t|
      t.references :order, null: false, foreign_key: true
      t.string :comment, null: false, default: ''
      t.boolean :canceled, null: false, default: false
      t.boolean :refunded, null: false, default: false
      t.float :refund_amt, null: false, default: 0.0

      t.timestamps
    end
  end
end
