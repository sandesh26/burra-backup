class CreateSlots < ActiveRecord::Migration[7.1]
  def change
    create_table :slots do |t|
      t.integer :quantity, null: false, default: 1
      t.date :date
      t.integer :package_type_id

      t.timestamps
    end
  end
end
