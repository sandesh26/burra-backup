class CreateOrderItems < ActiveRecord::Migration[7.1]
  def change
    create_table :order_items do |t|
      t.integer :order_id
      t.float :shared_discount_amnt, null: false, default: 0
      t.float :listing_amt
      t.integer :slots
      t.references :package_type

      t.timestamps
    end
    add_index :order_items, :order_id
  end
end
