class CreateDeepLinks < ActiveRecord::Migration[7.1]
  def change
    create_table :deep_links do |t|
      t.string :title
      t.string :internal_link
      t.string :external_link
      t.string :keywords
      t.string :description
      t.string :slug, index: { unique: true }
      
      t.timestamps
    end
  end
end
