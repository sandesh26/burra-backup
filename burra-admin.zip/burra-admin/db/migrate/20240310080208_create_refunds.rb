class CreateRefunds < ActiveRecord::Migration[7.1]
  def change
    create_table :refunds do |t|
      t.string :r_id
      t.float :amount
      t.string :payment_id
      t.string :status
      t.integer :order_id

      t.timestamps
    end
  end
end
