class CreateOrders < ActiveRecord::Migration[7.1]
  def change
    create_table :orders do |t|
      t.references :booking, null: false, foreign_key: true
      t.references :vendor, null: false, foreign_key: true
      t.references :entity, polymorphic: true, null: false
      t.datetime :check_out_date
      t.datetime :check_in_date
      t.integer :adults, null: false, default: 1
      t.integer :children, null: false, default: 0
      t.text :notes, null: false, default: ''
      t.float :listing_amt
      t.string :status
      t.string :entity_booking_id
      t.string :check_in_time, null: false, default: ''
      t.float :shared_discount_amnt, null: false, default: 0
      t.float :earned_amt
      t.integer :slots, null: false, default: 1

      t.timestamps
    end
  end
end
