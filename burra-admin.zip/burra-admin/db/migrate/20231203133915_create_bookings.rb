class CreateBookings < ActiveRecord::Migration[7.1]
  def change
    create_table :bookings do |t|
      t.references :customer, foreign_key: true
      t.integer :wallet_amount_used, null: false, default: 0
      t.float :subtotal
      t.float :discount_amount, null: false, default: 0
      t.float :paid_amt
      t.integer :coupon_id
      t.string :payment_id
      t.string :parent_booking_id
      t.jsonb :additional_info

      t.timestamps
    end
  end
end
