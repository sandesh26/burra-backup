class CreateBlogs < ActiveRecord::Migration[7.1]
  def change
    create_table :blogs do |t|
      t.string :title
      t.text :description
      t.references :blog_category
      t.boolean :status, null: false, default: true
      t.text :meta_description
      t.string :meta_keywords
      t.string :meta_title
      t.boolean :is_deleted, null: false, default: false

      t.timestamps
    end
  end
end
