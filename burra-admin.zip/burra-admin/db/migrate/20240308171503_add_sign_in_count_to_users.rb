class AddSignInCountToUsers < ActiveRecord::Migration[7.1]
  def change
    add_column :users, :sign_in_count, :integer, null: false, default: 0
    add_column :customers, :sign_in_count, :integer, null: false, default: 0
    add_column :vendors, :sign_in_count, :integer, null: false, default: 0
  end
end
