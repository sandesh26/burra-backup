class ChangeColumnTypeInActivities < ActiveRecord::Migration[7.1]
  def change
    remove_column :activities, :activity_category_id
    add_column :activities, :activity_category_ids, :text, array: true, default: []
  end
end
