class RemoveListingIdFromActivities < ActiveRecord::Migration[7.1]
  def change
    remove_column :activities, :listing_id, if_exists: true
  end
end