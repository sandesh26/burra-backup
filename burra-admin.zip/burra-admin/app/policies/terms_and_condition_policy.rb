class TermsAndConditionPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      scope.all
    end
  end

  def update?
    user.super_admin?
  end

  def index?
    true
  end
end
