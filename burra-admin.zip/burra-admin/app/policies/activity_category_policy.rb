class ActivityCategoryPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if user.super_admin? || user.admin? || user.activity_manager?
        scope.all
      else
        raise Pundit::NotAuthorizedError, 'You are not allowed to view this action'
      end
    end
  end

  def create?
    user.super_admin? || user.admin? || user.activity_manager?
  end

  def update?
    user.super_admin? || user.admin? || user.activity_manager?
  end

  def index?
    user.super_admin? || user.admin? || user.activity_manager?
  end

  def destroy?
    user.super_admin?
  end
end
