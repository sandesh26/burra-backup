class AppVersionPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if user.super_admin? || user.admin?
        scope.all
      else
        raise Pundit::NotAuthorizedError, 'You are not allowed to view this action'
      end
    end
  end

  def new?
    user.super_admin? || user.admin?
  end

  def edit?
    user.super_admin? || user.admin?
  end

  def create?
    user.super_admin? || user.admin?
  end

  def update?
    user.super_admin? || user.admin?
  end

  def index?
    user.super_admin? || user.admin?
  end

  def destroy?
    user.super_admin?
  end
end
