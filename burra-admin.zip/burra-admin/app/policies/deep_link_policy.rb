class DeepLinkPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if user.super_admin? || user.admin?
        scope.all
      else
        raise Pundit::NotAuthorizedError, 'You are not allowed to view this action'
      end
    end
  end

  def create?
    user.super_admin? || user.admin?
  end

  def update?
    user.super_admin? || user.admin?
  end

  def show?
    user.super_admin? || user.admin?
  end

  def index?
    user.super_admin? || user.admin?
  end

  def destroy?
    user.super_admin?
  end
end
