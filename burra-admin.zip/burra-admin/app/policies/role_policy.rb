class RolePolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if user.super_admin?
        scope.all
      else
        raise Pundit::NotAuthorizedError, 'You are not allowed to view this action'
      end
    end
  end

  def update?
    user.super_admin?
  end

  def index?
    user.super_admin?
  end
end
