class AppVersion < ApplicationRecord
	paginates_per 10
	validates_presence_of :app_name, :ios_version, :android_version
	validate :unique_version

  private

	def unique_version
		if id.nil? && AppVersion.where(app_name: app_name, ios_version: ios_version, android_version: android_version).exists?
	  		errors.add(:base, 'This version of app is already created')
	  end
	end
end