class Activity < ApplicationRecord
  extend FriendlyId
  friendly_id :name, use: :slugged
  paginates_per 10
  has_rich_text :description
  has_many_attached :files
  belongs_to :vendor
  belongs_to :location
  has_many :reviews, as: :entity, dependent: :destroy
  has_many :orders, as: :entity, dependent: :destroy
  has_many :packages, as: :entity, dependent: :destroy
  accepts_nested_attributes_for :packages, allow_destroy: true, reject_if: :all_blank

  # belongs_to :activity_category
  scope :available, -> { where(is_deleted: false)}
  scope :not_locked, -> { where(locked: false)}
  scope :all_day, -> { where(start_date: nil)}
  scope :not_expired, -> { where('start_date >= ?', Date.today)}
  scope :pending, -> { where.not(status: 'approved')}
  scope :approved, -> { where('activities.is_deleted IS ? and activities.status = ?', false, 'approved') }
  before_save :reject_empty
  before_save :set_filename

  validates_presence_of :start_time, :end_time, :latitude, :longitude, :location_id, :vendor_id

  STATUS = ['created', 'submitted', 'approved', 'rejected', 'suspended']

  def should_generate_new_friendly_id?
    name_changed?
  end

  def set_filename
    if self.files.attached?
      self.files.each do |file|
        file.blob.update(filename: "#{self.name.parameterize}.#{file.filename.extension}")
      end
    end
  end

  def file_url(image)
    if image.id
      image.variant(resize_to_limit: [640, 450]).processed.url
    end
    #   # return a default image or handle the case when image is not attached
    #   # For example:
    #   ActionController::Base.helpers.image_url('default_image.png')
    # end
  end

  private

  def reject_empty
    self.activity_category_ids = activity_category_ids.reject(&:blank?) unless activity_category_ids.blank?
  end


  def self.activities_with_most_positive_reviews_and_orders(top_acts=false)
    queryForGroupBy = ''
    if top_acts
      queryForGroupBy = 'activities.id'
    else
      queryForGroupBy = 'activities.id, reviews_activities.id'
    end
    select('activities.*, COUNT(DISTINCT reviews.id) AS total_reviews, AVG(reviews.star) AS average_rating, COUNT(DISTINCT orders.id) AS total_orders')
      .joins('LEFT JOIN reviews ON activities.id = reviews.entity_id AND reviews.entity_type = \'Activity\'')
      .joins('LEFT JOIN orders ON activities.id = orders.entity_id AND orders.entity_type = \'Activity\'')
      .group(queryForGroupBy)
      .having('COUNT(DISTINCT CASE WHEN reviews.star >= 4 THEN reviews.id END) > 0')  # At least one positive review
      .order('average_rating DESC, total_reviews DESC, total_orders DESC')
  end

  def self.search(params)
    _filter = params[:filter_by]

    activities = approved_with_associations(_filter)

    activities = activities._filter_by_category_ids(params[:activity_category_ids]) if params[:activity_category_ids].present?
    activities = activities._filter_by_location(params[:location_id]) if params[:location_id].present?

    if params[:ids]
      activities = activities.where(id: params[:ids])
    end

    # if params[:coordinates]
    #   coords = params[:coordinates].values.map(&:to_f)
    #   listings_ids = Listing.approved.nearby(coords).map(&:id)
    #   activities = activities.where(listing_id: listings_ids)
    # end

    # if params[:searchStr]
    #   str = params[:searchStr]
    #   activities = activities.where("LOWER(name) LIKE ?", "%#{str.downcase}%")
    # end

    if _filter
      activities = activities._filter_by_category_ids(_filter[:category].values) if _filter[:category]&.present?
      activities = activities._filter_by_price_range(_filter[:price_range].values) if _filter[:price_range]&.present?
      activities = activities._filter_by_person(_filter[:filterPerson]) if _filter[:filterPerson]&.present?
      activities = activities._filter_by_ratings(_filter[:start_rating]) if _filter[:start_rating]&.present?
      # activities = activities._filter_by_date(_filter[:filterDate]) if _filter[:filterDate]&.present?
    end

    sort_by = params[:sort_by]
    if sort_by
      activities = activities.order_by_price(sort_by[:value]) if sort_by[:key] == 'discounted_price' || sort_by[:key] == 'price_low'
      activities = activities.order_by_rating(sort_by[:value]) if sort_by[:key] == 'rating'
      activities = activities.order_by_popularity(sort_by[:value]) if sort_by[:key] == 'popularity'
    else
      activities = activities.order_by_created_at
    end

    activities
  end

  private

  scope :approved_with_associations, ->(fltr) {
    approved.all_day.includes(:reviews, :orders, :packages)
    # if fltr.present? && fltr[:category].present? && fltr[:filterDate].present?
    #   approved.includes(:reviews, :orders)
    # elsif fltr&.[](:filterDate)&.present?
    #   approved.includes(:reviews, :orders)
    # else
    #   approved.all_day.includes(:reviews, :orders)
    # end
  }

  scope :_filter_by_category, ->(category_id) {
    where(activity_category_ids: category_id) if category_id.present?
  }

  scope :_filter_by_location, ->(location_id) {
    if location_id.present?
      where(location_id: location_id)
    end
  }

  scope :order_by_created_at, -> { order(start_date: :asc) }

  scope :_filter_by_category_ids, ->(category_ids) {
    if category_ids.present?
      conditions = category_ids.map { |id| "? = ANY (activity_category_ids)" }.join(" OR ")
      where_clause = ActiveRecord::Base.sanitize_sql_array(["(#{conditions})", *category_ids])
      where(where_clause)
    end
  }

  scope :_filter_by_price_range, ->(price_range) {
    where(discounted_price: price_range[0]..price_range[1]) if price_range.present?
  }

  scope :_filter_by_person, ->(person) {
    if person.present? && person.to_i > 0
      group("activities.id, activities.max
        _person_allowed, active_storage_attachments.id, activity_categories.id, active_storage_blobs.id, reviews.id, orders.id").having("COALESCE(activities.max_person_allowed - SUM(order_items.slots), activities.max_person_allowed) >= ?", person.to_i)
    end
  }

  scope :order_by_price, ->(sort_order) {
    order("discounted_price #{sort_order}") if sort_order.present?
  }

  scope :order_by_rating, ->(sort_order) {
    left_joins(:reviews)
    .group('activities.id')
    .references(:reviews)
    .order(Arel.sql('COALESCE(AVG(reviews.star), 0) DESC')) if sort_order.present?
  }

  scope :order_by_popularity, ->(sort_order) {
    activities_with_most_positive_reviews_and_orders
  }

  scope :_filter_by_ratings, ->(start_rating) {
    if start_rating.present?
      review_ids = Review.where('entity_type =? and star >= ?', 'Activity', start_rating.values[0]).pluck(:entity_id)
      where(id: review_ids)
    end
    # joins(:reviews).where('reviews.star >= ?', start_rating.values[0])
  }

  scope :_filter_by_date, ->(date) {
    where(start_date: Date.parse(date))
  }

end
