class Role < ApplicationRecord
  validates_uniqueness_of :name
  has_many :vendors
  has_many :customers
  has_many :users
end