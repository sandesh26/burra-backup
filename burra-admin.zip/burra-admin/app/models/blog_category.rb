class BlogCategory < ApplicationRecord
  paginates_per 10
  has_many :blogs
  validates_uniqueness_of :title
end
