class Coupon < ApplicationRecord
  paginates_per 10
  has_one_attached :image
  has_rich_text :description
  COUPON_TYPE = ['Flat', 'Percentage']
  has_many :bookings
  validates_presence_of :min_cart_val, :coupon_code, :valid_from, :valid_till, :title, :description
  scope :active, -> { where(status: true) }
  scope :common, -> { where(common: true) }
  scope :internal, -> { where(common: false) }

  before_save :upcase_coupon_code
  before_save :set_filename


  private

  def set_filename
    if self.image.attached?
      self.image.blob.update(filename: "#{self.title.parameterize}.#{self.image.filename.extension}")
    end
  end

  def upcase_coupon_code
    self.coupon_code = coupon_code.upcase
  end
end
