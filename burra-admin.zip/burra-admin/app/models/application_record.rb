class ApplicationRecord < ActiveRecord::Base
  primary_abstract_class
  def self.inherited subclass
    skipped_models = ["ActiveRecord::SchemaMigration", "PaperTrail::Version"]
    super
    unless skipped_models.include?(subclass.to_s)
      # subclass.send(:has_paper_trail)
    end
  end
end
