class Cancelation < ApplicationRecord
  paginates_per 10
  belongs_to :order

  def cancel_order
    BookingCancelationJob.perform_async(self.id)
  end
end
