class Package < ApplicationRecord
	has_rich_text :details
	belongs_to :entity, polymorphic: true
	has_many :package_types, dependent: :destroy
  accepts_nested_attributes_for :package_types, allow_destroy: true, reject_if: :all_blank

  validates_presence_of :title

  # validate :package_details

  private
  
  def package_details
    # errors.add(:details, "can't be empty") if details.body.blank?
  end
end