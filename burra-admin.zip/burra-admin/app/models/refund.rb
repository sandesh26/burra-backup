class Refund < ApplicationRecord
	paginates_per 10
end
