class Wishlist < ApplicationRecord
  paginates_per 10
  belongs_to :customer
  belongs_to :entity, polymorphic: true
end
