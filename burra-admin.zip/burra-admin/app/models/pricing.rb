class Pricing < ApplicationRecord
  belongs_to :listing
end
