class HouseCategory < ApplicationRecord
  has_one_attached :image
  has_many :rooms
  validates_uniqueness_of :name
  validates_presence_of :name
  scope :active, -> { where(status: true)}
end
