class Item < ApplicationRecord
  belongs_to :entity, polymorphic: true
  belongs_to :cart
  belongs_to :package_type
  COMMISSION_AMOUNT = 15.freeze

  def self.checkout(params, customer, parent_booking_id)
    ActiveRecord::Base.transaction do

      return if params["razorpay_payment_id"].present?

      booking_data = params["bookingData"].transform_keys(&:to_sym)
      wallet_used_amt = booking_data[:wallet_used_amt].to_i
      payment_id = params["transactionId"]

      email = booking_data[:email]

      if customer.email.nil? || customer.email === 'null'
        customer.update(email: email)
      end

      @booking = customer.bookings.build(
        wallet_amount_used: wallet_used_amt,
        coupon_id: booking_data[:coupon_id],
        subtotal: booking_data[:subtotal].to_f,
        discount_amount: booking_data[:discount].to_f,
        paid_amt: booking_data[:paid_amt].to_f,
        parent_booking_id: parent_booking_id,
        payment_id: payment_id,
        email: email
      )
      @booking.save

      order_details = booking_data[:orderDetails]

      shared_discount_amnt = (@booking.discount_amount.to_f / order_details.keys.length)

      coins = [@booking.paid_amt * 0.01, 50].min.round

      wallet = customer.wallet

      if wallet_used_amt > 0
        wallet.decrement!(:balance, wallet_used_amt)
        wallet.transactions.build(transaction_type: 'deduct', amount: wallet_used_amt)
        wallet.save
      end

      if payment_id.present?
        wallet = wallet.increment!(:balance, coins)
        wallet.transactions.build(transaction_type: 'add', amount: coins)
        wallet.save
      end

      order_details.each do |entity_id, entities|
        __id = entity_id.split('_')[0]
        entity = Activity.find_by(id: __id)

        order_record = Order.new(
          booking: @booking,
          entity: entity,
          vendor: entity.vendor,
          status: payment_id ? 'confirmed' : 'initiated',
          entity_booking_id: "B" + SecureRandom.urlsafe_base64(6).upcase + customer.id.to_s + entity.id.to_s,
          shared_discount_amnt: shared_discount_amnt
        )
        order_record.save

        entities.each do |order|
          slots = order["quantity"].to_i
          listing_amt = order["listingAmt"].to_f
          package_type = PackageType.find_by(id: order["packageTypeId"])
          earned_amt = package_type.vendor_price * slots

          order_record.order_items.build(
            listing_amt: listing_amt,
            slots: slots,
            package_type_id: order["packageTypeId"]
          ).save

          order_record.update(
            check_in_date: order["checkInDate"],
            earned_amt: earned_amt
          )
          if payment_id.present?
            vendor = entity.vendor
            v_wallet = vendor.wallet
            v_wallet.increment!(:balance, earned_amt)
            v_wallet.transactions.build(transaction_type: 'add', amount: earned_amt)
            v_wallet.save
          end
        end

        if payment_id.present?
          customer.wishlists.where(entity: entity).delete_all
          customer.cart.items.delete_all
        end

      end

      if payment_id.present?
        BookingConfirmationJob.perform_async(@booking.id)
      end
    end

  end

  def self.get_entity(entity_id, entity_type)
    entity = case entity_type
           when 'Activity' then Activity.find_by(id: entity_id)
           when 'Room' then Room.find_by(id: entity_id)
           when 'Car' then Car.find_by(id: entity_id)
           else nil
           end
    entity
  end

  def self.check_availability(selected_date, entity, cart, package_type_id, selected_slots=1, is_adding_to_cart=false)
    pt_msg = 'All slots are booked'
    max_available = 0

    if selected_date < Date.today
      return { response: false, pt_message: "Selected date can't be past date" }
    elsif entity.start_date.present? and entity.start_date < Date.today
      return { response: false, pt_message: "Activity unavailable. Scheduled date has passed" }
    end

    # if entity.prior_booking and selected_date == Date.today
    #   return { response: false, pt_message: "All slots are booked on selected date" }
    # end

    if entity.prior_booking and entity.start_date.present? and entity.start_date <= Date.today
      return { response: false, pt_message: "All slots are booked on selected date" }
    end

    if entity.prior_booking and entity.start_date.nil? and selected_date >= Date.today
      return { response: false, pt_message: "All slots are booked on selected date" }
    end

    beginning_of_day = selected_date.beginning_of_day
    end_of_day = selected_date.end_of_day



    package_type = PackageType.find_by(id: package_type_id)
    slots = package_type.slots
    if entity.start_date.present?
      custom_slots = slots.where('date <= ?', entity.start_date).first
    else
      custom_slots = slots.where(date: selected_date).first
    end

    if slots.first.date.nil?
      max_available = slots.first&.quantity
    elsif custom_slots
      max_available = custom_slots.quantity
    else
      pt_msg = 'No slots are available on selected date'
    end

    orders = Order.joins(:order_items).where(entity: entity).not_initiated.where("check_in_date >= ? AND check_in_date <= ?", beginning_of_day, end_of_day).sum("order_items.slots")

    items = cart.items.where(entity: entity).where(package_type_id: package_type_id).length
    available_slots = max_available - orders

    puts "available_slots #{available_slots}"
    puts "selected_slots #{selected_slots}"
    puts "items #{items}"

    if available_slots <= 0
      return { response: false, pt_message: pt_msg }
    elsif is_adding_to_cart and items === available_slots
      return { response: false, pt_message: "Only #{available_slots} available slot(s) and already added to your cart" }
    elsif selected_slots > available_slots
      return { response: false, pt_message: "Only #{available_slots} slot(s) are left" }
    elsif items > available_slots
      return { response: false, pt_message: "Only #{available_slots} slot(s) are available" }
    else
      return { response: true, pt_message: '' }
    end
  end

end
