class ActivityCategory < ApplicationRecord
  has_one_attached :image
  validates_uniqueness_of :name
  validates_presence_of :name
  # has_many :activities, dependent: :destroy
  scope :active, -> { where(status: true)}
  before_save :set_filename

  scope :with_approved_activities, -> {
    joins(:activities)
      .where('activities.is_deleted = ? AND activities.status = ?', false, 'approved')
      .distinct
  }


  private

  def set_filename
    if self.image.attached?
      self.image.blob.update(filename: "#{self.name.parameterize}.#{self.image.filename.extension}")
    end
  end

end