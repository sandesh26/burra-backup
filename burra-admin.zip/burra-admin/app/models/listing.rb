class Listing < ApplicationRecord
  paginates_per 10
  has_one_attached :documentid
  belongs_to :vendor
  belongs_to :listing_category
  belongs_to :location
  # has_one :property, dependent: :destroy
  # has_one :amenity, dependent: :destroy
  has_many :cars, dependent: :destroy
  has_many :activities, dependent: :destroy
  has_many :rooms, dependent: :destroy
  # has_one :pricing, dependent: :destroy
  validates_presence_of :listing_category_id

  scope :available, -> { where(is_deleted: false)}
  scope :approved, -> { where('is_deleted IS ? and status =?', false, 'approved')}

  STATUS = ['created', 'submitted', 'approved', 'rejected', 'suspended']

  geocoded_by :address, latitude: :latitude, longitude: :longitude
  after_validation :geocode

  def self.nearby(coordinates, radius = 20)
    near(coordinates, radius, units: :km)
  end
end