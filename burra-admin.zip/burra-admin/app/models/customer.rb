require 'open-uri'

class Customer < ApplicationRecord
  paginates_per 10
  default_scope { order(created_at: :desc) }
  
  has_one_attached :image
  has_many :device_tokens, as: :client
  has_one :wallet, as: :entity, dependent: :destroy
  has_one :cart, dependent: :destroy
  has_many :wishlists, dependent: :destroy
  has_many :bookings, dependent: :destroy
  has_many :complaints, dependent: :destroy
  scope :verified, -> { where(status: 'verified')}

  validates_uniqueness_of :phone, if: :phone_present?
  validates_uniqueness_of :email, if: :email_present?
  after_save :create_wallet
  after_save :create_cart

  def grab_image(profile_img_url)
    downloaded_image = URI.parse(profile_img_url).open
    self.image.attach(io: downloaded_image  , filename: "profile_#{self.email}.jpg")
  end

  def full_name
    first_name.to_s + " #{last_name.to_s}"
  end

  def create_wallet
    self.build_wallet(balance: 0).save if self.wallet.nil?
  end

  def create_cart
    self.build_cart.save if self.cart.nil?
  end

  def sync_user_cart(userId=nil)
    if userId.present?
      klass = Object.const_get('Customer')
      temp_customer = klass.find_by(id: userId)
      
      if temp_customer.present?
        temp_cart = temp_customer.cart
        temp_cart_items = temp_cart.items

        temp_cart_items.each do |temp_item|
          new_item = self.cart.items.build(temp_item.attributes.except('id', 'created_at', 'updated_at')) 
          new_item.cart_id = self.cart.id
          new_item.save!
        end
        if self.cart.save
          temp_customer.destroy
        end
      end
    end    
  end

  def new_otp
    rand(100_000..999_999)
  end

  private

  def phone_present?
    phone.present?
  end

  def email_present?
    email.present?
  end
end