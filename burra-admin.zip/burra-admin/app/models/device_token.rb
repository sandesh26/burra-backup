class DeviceToken < ApplicationRecord
  belongs_to :client, polymorphic: true, optional: true
  validates_uniqueness_of :token
end