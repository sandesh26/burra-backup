class Review < ApplicationRecord
  paginates_per 10
  default_scope { order(created_at: :desc) }
  RATINGS = [1, 2, 3, 4, 5]
  scope :available, -> { where.not(customer: '')}
  scope :approved, -> { where(is_approved: true)}

  belongs_to :entity, polymorphic: true
  # before_save :approve_if_rating_only

  def customer_name
    Customer.find_by(id: customer)&.full_name || customer
  end

  def approve_if_rating_only
    self.is_approved = true
  end
end
