class CancelationRequest < ApplicationRecord
end
