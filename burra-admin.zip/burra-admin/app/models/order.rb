class Order < ApplicationRecord
  has_one_attached :qrcode, dependent: :destroy
  before_commit :generate_qrcode, on: :create

  paginates_per 10
  belongs_to :booking
  belongs_to :vendor
  belongs_to :entity, polymorphic: true
  has_one :cancelation, dependent: :destroy
  scope :canceled, -> { where(status: 'canceled')}
  scope :confirmed, -> { where(status: 'confirmed')}
  scope :not_initiated, -> { where.not(status: 'initiated')}
  scope :not_canceled, -> { where.not(status: 'canceled')}

  has_many :order_items, dependent: :destroy

  def customer_paid
    paid_amt = 0
    order_items.each do |ot|
      paid_amt += ot.listing_amt - ot.shared_discount_amnt
    end
    paid_amt
  end

  def customer_shared_discount
    shared_amt = 0
    order_items.each do |ot|
      shared_amt += ot.shared_discount_amnt
    end
    shared_amt
  end

  private

  def generate_qrcode
    qrcode = RQRCode::QRCode.new(JSON.generate(self.entity_booking_id.to_s))

    png = qrcode.as_png(
      bit_depth: 1,
      border_modules: 4,
      color_mode: ChunkyPNG::COLOR_GRAYSCALE,
      color: "#36454F",
      file: nil,
      fill: "white",
      module_px_size: 6,
      resize_exactly_to: false,
      resize_gte_to: false,
      size: 250,
    )

    self.qrcode.attach(
      io: StringIO.new(png.to_s),
      filename: "#{self.entity_booking_id}.png",
      content_type: "image/png",
    )
  end
end
