class Complaint < ApplicationRecord
  belongs_to :entity, polymorphic: true
  belongs_to :customer
  scope :available, -> { where.not(status: 'deleted')}

  before_save :generate_reference_no

  private
  def generate_reference_no
    self.reference_no = entity&.name&.upcase.to_s + SecureRandom.random_number(100000000000000).to_s + id.to_s if self.id
  end

end