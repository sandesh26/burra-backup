class Booking < ApplicationRecord
  store_accessor :additional_info, :email
  default_scope { order(created_at: :desc) }
  belongs_to :customer
  # scope :available, -> { where.not(status: 'deleted')}
  belongs_to :coupon, optional: true
  has_many :orders, dependent: :destroy


  def self.categorize_bookings(customer, order_ids, activity_ids)
    today = Time.zone.now.to_date
    upcoming_bookings = []
    completed_bookings = []

    activity_hash = Activity.where(id: activity_ids).index_by(&:id)

    _orders = Order.not_initiated.includes(:booking).order(check_in_date: :asc).where(id: order_ids)

    _orders.each do |order|
      booking = order.booking
      shared_wallet_amount_used = (booking.wallet_amount_used / booking.orders.length)
      order_date = order.check_in_date.to_date
      entity_type = order.entity_type
      entity_id = order.entity_id
      entity = activity_hash[entity_id]
      order_items = order.order_items

      order_obj = {
        id: order.id,
        checkInDate: order.check_in_date,
        entityBookingId: order.entity_booking_id,
        entityId: entity_id,
        status: order.status,
        paidAmt: (order_items.sum(:listing_amt) - (order.shared_discount_amnt + shared_wallet_amount_used)) * order_items.sum(:slots),
        slots: order_items.sum(:slots)
      }

      update_entity_attributes(order_obj, entity)

      if order_date >= today && order.status != 'canceled'
        upcoming_bookings << order_obj
      else
        if order_date < today
          order.update(status: 'completed')
        end
        completed_bookings << order_obj
      end
    end

    { upcoming: upcoming_bookings, completed: completed_bookings, all_bookings: upcoming_bookings + completed_bookings }
  end


  def self.categorize_bookings_for_vendor(vendor, url, activity_ids, room_ids, car_ids)
    today = Time.zone.now.to_date
    upcoming_bookings = []
    completed_bookings = []
    cancelled_bookings = []

    activity_hash = Activity.where(id: activity_ids).index_by(&:id)

    vendor.orders.not_initiated.includes(:entity).order(check_in_date: :asc).each do |order|
      order_date = order.check_in_date.to_date

      entity = activity_hash[order.entity_id]

      order_obj = {
        id: order.id,
        activity_category_ids: entity.activity_category_ids,
        slots: order.order_items.sum(:slots),
        check_in_date: order.check_in_date,
        created_at: order.check_in_date
      }

      update_entity_attributes(order_obj, entity)

      if order.status == 'canceled'
        cancelled_bookings << order_obj
      elsif order_date >= today and order.status == 'confirmed'
        upcoming_bookings << order_obj
      elsif order.status == 'completed'
        completed_bookings << order_obj
      elsif order_date < today
        order.update(status: 'completed')
        completed_bookings << order_obj
      end
    end

    { upcoming: upcoming_bookings, completed: completed_bookings, cancelled: cancelled_bookings }
  end


  def self.update_entity_attributes(order_obj, entity)
    return unless entity

    order_obj[:primary_image] = entity.files.attached? ? entity.files[0].url : ''
    order_obj[:name] = entity.name
    order_obj[:description] = entity.description.body.to_plain_text
    # order_obj[:packages] = entity.packages.length
  end


end
