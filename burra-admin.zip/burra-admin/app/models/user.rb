class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  belongs_to :role
  # after_initialize :assign_role

  # private
  # def assign_role
  #   self.role_id = Role.find_by(name: 'super_admin').id
  # end

  def super_admin?
    role.name == 'super_admin'
  end

  def admin?
    role.name == 'admin'
  end

  def activity_manager?
    role.name == 'activity_manager'
  end

  def blog_manager?
    role.name == 'blog_manager'
  end
end
