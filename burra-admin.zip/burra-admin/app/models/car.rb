class Car < ApplicationRecord
  paginates_per 10
  has_many_attached :files
  has_many :reviews, as: :entity
  belongs_to :listing
  belongs_to :car_seat
  belongs_to :car_type
  belongs_to :car_fuel_type
  belongs_to :car_transmission
  scope :available, -> { where(is_deleted: false)}
  scope :approved, -> { where('cars.is_deleted IS ? and cars.status = ?', false, 'approved') }
end