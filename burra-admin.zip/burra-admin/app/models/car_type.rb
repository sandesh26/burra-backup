class CarType < ApplicationRecord
  has_one_attached :image
  validates_uniqueness_of :name
  validates_presence_of :name
  scope :active, -> { where(status: true)}
  has_many :cars
end
