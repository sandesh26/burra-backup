class Transaction < ApplicationRecord
  paginates_per 10
  belongs_to :wallet
end
