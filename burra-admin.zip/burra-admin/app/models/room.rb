class Room < ApplicationRecord
  paginates_per 10
  has_many_attached :files
  has_many :reviews, as: :entity
  belongs_to :listing
  belongs_to :house_category
  belongs_to :property_type
  scope :available, -> { where(is_deleted: false)}
  scope :approved, -> { where('rooms.is_deleted IS ? and rooms.status = ?', false, 'approved') }

  before_save :reject_empty

  private
  def reject_empty
    self.amenities = amenities.reject(&:blank?) unless amenities.blank?
    self.house_rules = house_rules.reject(&:blank?) unless house_rules.blank?
  end
end
