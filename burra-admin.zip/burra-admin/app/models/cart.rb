class Cart < ApplicationRecord
  belongs_to :customer
  has_many :items, dependent: :destroy
  validates_uniqueness_of :customer_id

  def self.get_user_cart(user_id)
    customer_id = Customer.find_or_create_by(id: user_id).id
    Cart.find_or_create_by(customer_id: customer_id)
  end

end