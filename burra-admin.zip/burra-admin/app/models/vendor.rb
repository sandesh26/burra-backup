class Vendor < ApplicationRecord
  paginates_per 10
  has_one_attached :documentid
  has_one_attached :license
  # default_scope { order(created_at: :desc) }
  # has_many_attached :photos do |attachable|
  #   attachable.variant :preview, resize_to_limit: [280, 280], quality: 80, strip: true, format: :webp
  # end
  # has_one_attached :image, variants: {
  #   thumb: { resize: "100x100" },
  #   medium: { resize: "300x300", monochrome: true }
  # }
  has_one :wallet, as: :entity, dependent: :destroy
  has_many :device_tokens, as: :client
  has_one_attached :image
  has_many :account_details, dependent: :destroy
  has_many :activities, dependent: :destroy
  has_many :orders, dependent: :destroy
  has_many :account_details, dependent: :destroy
  accepts_nested_attributes_for :account_details, allow_destroy: true, reject_if: :all_blank
  validates_uniqueness_of :phone
  validates :phone, :presence => true,
                    :numericality => true,
                    :length => { :minimum => 10, :maximum => 10 }

  before_save :downcase_email
  after_save :create_wallet

  STATUS = ['created', 'submitted', 'approved', 'rejected', 'suspended']
  DOCUMENT_TYPE = ['Driving License', 'Passport', 'Voter ID', 'Aadhaar card', 'Government-issued ID']

  def full_name
    first_name.to_s + " #{middle_name.to_s}" + " #{last_name.to_s}"
  end

  def create_wallet
    self.build_wallet(balance: 0).save if self.wallet.nil?
  end

  private

  def downcase_email
    self.email = email.downcase if email
  end
end
