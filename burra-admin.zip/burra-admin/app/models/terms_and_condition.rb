class TermsAndCondition < ApplicationRecord
  has_rich_text :content
end
