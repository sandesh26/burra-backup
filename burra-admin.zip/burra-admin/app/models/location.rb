class Location < ApplicationRecord
  scope :active, -> { where(status: true)}
  has_many :activities
  has_one_attached :image
  before_save :capitalize_name
  before_save :set_filename

  private

  def set_filename
    if self.image.attached?
      self.image.blob.update(filename: "#{self.name.parameterize}.#{self.image.filename.extension}")
    end
  end

  def capitalize_name
    self.name = name.capitalize
  end
end
