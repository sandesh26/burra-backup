class Wallet < ApplicationRecord
  paginates_per 10
  TRANSACTION_TYPE = ['add', 'deduct']
  belongs_to :entity, polymorphic: true
  has_many :transactions
  validates :balance, presence: true
  scope :customer_wallet, -> { where(entity_type: 'Customer')}
  scope :vendor_wallet, -> { where(entity_type: 'Vendor')}

  def create_transaction(transaction_type, bal=0)
    _transaction = transactions.build
    _transaction.transaction_type = transaction_type
    _transaction.amount = bal.to_i
    _transaction.save
  end
end