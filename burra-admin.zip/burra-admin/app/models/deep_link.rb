class DeepLink < ApplicationRecord
  extend FriendlyId
  friendly_id :title, use: :slugged
  paginates_per 10
  validates_presence_of :title, :internal_link
  validates_uniqueness_of :title
  before_save :update_external_link

  def should_generate_new_friendly_id?
    slug.blank? || title_changed?
  end

  def update_external_link
    self.external_link = "https://www.burraa.com/activities/#{slug}"
  end
end
