class PropertyType < ApplicationRecord
  validates_uniqueness_of :name
  scope :active, -> { where(status: true)}
end
