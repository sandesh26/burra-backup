class PackageType < ApplicationRecord
	belongs_to :package
	has_one :item
	validates_presence_of :title, :details, :price, :vendor_price, :offer_price

	has_many :slots, dependent: :destroy
  accepts_nested_attributes_for :slots, allow_destroy: true, reject_if: :all_blank
end
