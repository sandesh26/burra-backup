class AccountDetail < ApplicationRecord
  belongs_to :vendor
end
