class AppNotification < ApplicationRecord
	validates_presence_of :client_type, :title, :body
end
