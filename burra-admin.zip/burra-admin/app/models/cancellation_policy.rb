class CancellationPolicy < ApplicationRecord
  has_rich_text :content
end
