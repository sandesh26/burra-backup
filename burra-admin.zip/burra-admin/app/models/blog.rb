class Blog < ApplicationRecord
  extend FriendlyId
  friendly_id :title, use: :slugged
  paginates_per 10
  has_one_attached :cover_image
  has_rich_text :description
  belongs_to :blog_category
  validates_uniqueness_of :title

  scope :active, -> { where(status: true) }
  scope :inactive, -> { where(status: false) }

  before_save :set_filename

  def should_generate_new_friendly_id?
    title_changed?
  end
  
  private

  def set_filename
    if self.cover_image.attached?
      self.cover_image.blob.update(filename: "#{self.title.parameterize}.#{self.cover_image.filename.extension}")
    end
  end

end
