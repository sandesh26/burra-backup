class ListingCategory < ApplicationRecord
  validates_uniqueness_of :name
  has_many :rooms
  has_many :activities
  has_many :cars
  has_many :listings
end