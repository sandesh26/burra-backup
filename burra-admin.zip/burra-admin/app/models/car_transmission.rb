class CarTransmission < ApplicationRecord
  has_many :cars
  validates_uniqueness_of :name
  scope :active, -> { where(status: true)}
end
