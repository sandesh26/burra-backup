class Slot < ApplicationRecord
	belongs_to :package_type
	validates_presence_of :quantity
end
