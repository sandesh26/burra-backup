class Property < ApplicationRecord
  belongs_to :listing
end
