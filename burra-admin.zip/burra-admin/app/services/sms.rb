require 'net/http'

class Sms
  def initialize(phone_number, otp)
    @phone_number = phone_number
    @otp = otp
  end

  def send_otp
    url = URI("https://control.msg91.com/api/v5/flow/")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["accept"] = 'application/json'
    request["content-type"] = 'application/json'

    request["authkey"] = Rails.application.credentials.msg91.auth_key
    request.body = {"template_id"=>Rails.application.credentials.msg91.template_id, "short_url"=>"1 (On) or 0 (Off)", "recipients"=>[{"mobiles"=>"91"+@phone_number.to_s, "otp"=>@otp}]}.to_json

    response = http.request(request)
    puts "RESPONSE::::::::::::::::: #{response.read_body}"
  end
end