require 'base64'
require 'openssl'
require 'net/http'

class Phonepe

  def initialize
    @host_url = Rails.application.credentials.dig(:phonepe, :host)
    @refund_url = "https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/refund"
    @merchant_id = Rails.application.credentials.dig(:phonepe, :merchant_id)
    @api_key = Rails.application.credentials.dig(:phonepe, :api_key)
  end

  def get_payment_url(params, customer)
    booking_data = params["bookingData"].transform_keys(&:to_sym)

    if Rails.env == 'production'
      callback_url = 'https://admin.burraa.com/payments/success'
      redirect_url = 'https://admin.burraa.com/payments/success'
    else
      callback_url = 'http://192.168.153.203:3000/payments/success'
      redirect_url = 'http://192.168.153.203:3000/payments/success'
    end

    merchantTransactionId = "B" + SecureRandom.urlsafe_base64(8).upcase + customer.id.to_s

    payment_data = {
      merchantId: @merchant_id,
      merchantTransactionId: merchantTransactionId,
      merchantUserId: customer.id,
      amount: booking_data[:paid_amt].to_i * 100,
      redirectUrl: redirect_url,
      redirectMode: 'POST',
      callbackUrl: callback_url,
      mobileNumber: customer.phone,
      paymentInstrument: {
        type: 'PAY_PAGE'
      }
    }

    json_encode = JSON.generate(payment_data)

    payload_main = Base64.strict_encode64(json_encode)

    payload = "#{payload_main}/pg/v1/pay#{@api_key}"
    sha256 = OpenSSL::Digest::SHA256.hexdigest(payload)

    salt_index = 1
    final_x_header = "#{sha256}####{salt_index}"

    uri = URI(@host_url)
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(uri.path, 'Content-Type' => 'application/json')
    request['X-VERIFY'] = final_x_header
    request.body = { request: payload_main }.to_json

    response = http.request(request)
    parsed = JSON.parse(response.body)
    # puts "PHONEPE PARSED DATA FOR PAYMENT URL::::::: #{parsed}"
    self_checkout = Item.checkout(params, customer, parsed["data"]["merchantTransactionId"])
    parsed["data"]["instrumentResponse"]["redirectInfo"]["url"]
  end


  # Refund API
  def refund(cancelation, customer, refund_amt, payment_id)

    if Rails.env == 'production'
      callback_url = "https://admin.burraa.com/cancelations/#{cancelation.id}"
    else
      callback_url = "http://172.20.10.3:3000/cancelations/#{cancelation.id}"
    end

    order = cancelation.order

    payment_data = {
      merchantId: @merchant_id,
      merchantTransactionId: order.entity_booking_id,
      originalTransactionId: payment_id,
      merchantUserId: customer.id,
      amount: refund_amt * 100,
      callbackUrl: callback_url
    }

    json_encode = JSON.generate(payment_data)

    payload_main = Base64.strict_encode64(json_encode)

    payload = "#{payload_main}/pg/v1/refund#{@api_key}"
    sha256 = OpenSSL::Digest::SHA256.hexdigest(payload)

    salt_index = 1
    final_x_header = "#{sha256}####{salt_index}"

    uri = URI(@refund_url)
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(uri.path, 'Content-Type' => 'application/json')
    request['X-VERIFY'] = final_x_header
    request.body = { request: payload_main }.to_json

    response = http.request(request)
    # parsed = JSON.parse(response.body)
    puts "RESPONSE:::::#{response}"
  end
end
