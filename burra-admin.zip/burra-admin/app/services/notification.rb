require 'googleauth'
require 'json'
require 'fcm'

class Notification
  def initialize(device_tokens, title, body, route_name=nil, action_id=nil, screen_name=nil)
    @device_tokens = device_tokens
    @title = title
    @body = body
    @route_name = route_name
    @screen_name = screen_name
    @action_id = action_id
  end


  def get_access_token
    key = JSON.parse(File.read('config/burraa-bfdb6-552f646e69ce.json'))
    scopes = ['https://www.googleapis.com/auth/firebase.messaging']

    credentials = Google::Auth::ServiceAccountCredentials.make_creds(
      json_key_io: StringIO.new(key.to_json),
      scope: scopes
    )

    credentials.fetch_access_token!
  end

  def send_notification
    access_token = get_access_token
    url = URI.parse('https://fcm.googleapis.com/v1/projects/burraa-bfdb6/messages:send')

    headers = {
      'Authorization' => "Bearer #{access_token['access_token']}",
      'Content-Type' => 'application/json'
    }

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    @device_tokens.each_slice(500) do |tokens_batch|
      tokens_batch.each do |token|
        payload = {
          "message" => {
            "token" => token,
            "notification" => {
              "title" => @title,
              "body" => @body
            },
            "data" => {
              "routeName" => @route_name,
              "screenName" => @screen_name,
              "actionId" => @action_id
            },
            "android" => {
              "notification" => {
                "body" => @body,
                "sound" => "default"
              }
            },
            "apns" => {
              "payload" => {
                "aps" => {
                  "category" => "NEW_MESSAGE_CATEGORY",
                  "sound" => "default"
                }
              }
            }
          }
        }

        request = Net::HTTP::Post.new(url.request_uri, headers)
        request.body = payload.to_json

        response = http.request(request)
        handle_response(response)
      end
    end
  end

  def handle_response(response)
    if response.code.to_i == 200
      puts "Notification sent successfully: #{response.body}"
    else
      puts "Error sending notification: #{response.code} - #{response.body}"
    end
  end

end