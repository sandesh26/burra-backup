require 'net/http'
require 'uri'
require 'json'

class Razorpay
  def initialize
    @api_key = "#{Rails.application.credentials.dig(:razorpay, :api_key)}:#{Rails.application.credentials.dig(:razorpay, :secret_key)}"
    @headers = {
      'Content-Type' => 'application/json',
      'Authorization' => "Basic #{Base64.strict_encode64(@api_key)}"
    }
  end

  def create_order(amount)
    url = URI.parse('https://api.razorpay.com/v1/orders')
    data = { amount: amount * 100, currency: "INR" }

    perform_request(url, data)
  end

  def initiate_refund(payment_id, amount)
    url = URI.parse("https://api.razorpay.com/v1/payments/#{payment_id}/refund")
    data = { amount: amount * 100 }

    perform_request(url, data)
  end

  private

  def perform_request(url, data)
    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url.path, @headers)
    request.body = data.to_json

    response = http.request(request)
    JSON.parse(response.body)
  end
end
