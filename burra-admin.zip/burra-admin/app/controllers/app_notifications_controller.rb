class AppNotificationsController < ApplicationController
  before_action :set_app_notification, only: %i[ show edit update ]

  def index
    policy_scope(AppNotification)
    @app_notifications = AppNotification.page params[:page]
  end

  def show
  end

  def new
    @app_notification = AppNotification.new
  end

  def edit
  end

  def create
    @app_notification = AppNotification.new(app_notification_params)
    authorize @app_notification
    respond_to do |format|
      if @app_notification.save
        NotificationsJob.perform_async(@app_notification.client_type, @app_notification.title, @app_notification.body)
        format.html { redirect_to app_notification_url(@app_notification), notice: "App notification was successfully created." }
        format.json { render :show, status: :created, location: @app_notification }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @app_notification.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @app_notification.update(app_notification_params)
        format.html { redirect_to app_notification_url(@app_notification), notice: "App notification was successfully updated." }
        format.json { render :show, status: :ok, location: @app_notification }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @app_notification.errors, status: :unprocessable_entity }
      end
    end
  end

  private
    def set_app_notification
      @app_notification = AppNotification.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def app_notification_params
      params.require(:app_notification).permit(:title, :body, :client_type, :scheduled_at, :client_ids, :click_action, :click_id)
    end
end
