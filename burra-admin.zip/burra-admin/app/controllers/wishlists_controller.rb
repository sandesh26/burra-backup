class WishlistsController < ApplicationController
  before_action :set_wishlist, only: %i[ show ]

  def index
    @wishlists = Wishlist.order(:listing_type).page params[:page]
  end

  def show
  end

  private
    def set_wishlist
      @wishlist = Wishlist.find(params[:id])
    end
end
