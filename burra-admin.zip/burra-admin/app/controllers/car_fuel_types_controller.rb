class CarFuelTypesController < ApplicationController
  before_action :set_amenity, only: %i[ show edit update destroy ]

  def index
    @car_fuel_types = CarFuelType.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @car_fuel_type = CarFuelType.new
  end

  def edit
  end

  def create
    @car_fuel_type = CarFuelType.new(car_fuel_type)

    respond_to do |format|
      if @car_fuel_type.save
        format.html { redirect_to car_fuel_types_url, notice: "Fuel type was successfully created." }
        format.json { render :show, status: :created, location: @car_fuel_type }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @car_fuel_type.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @car_fuel_type.update(car_fuel_type)
        format.html { redirect_to car_fuel_types_url, notice: "Fuel type was successfully updated." }
        format.json { render :show, status: :ok, location: @car_fuel_type }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @car_fuel_type.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @car_fuel_type.destroy!

    respond_to do |format|
      format.html { redirect_to car_fuel_types_url, notice: "Fuel type was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    def set_amenity
      @car_fuel_type = CarFuelType.find(params[:id])
    end

    def car_fuel_type
      params.require(:car_fuel_type).permit(:name, :status)
    end
end
