class AuditsController < ApplicationController
  before_action :set_data, only: %i[ index ]

  def index
    if params[:module]
      @audits = PaperTrail::Version.where('item_type=? and whodunnit like ? and object_changes is not ?', params[:module], "%#{params[:user_id]}%", nil).order(created_at: :desc).page params[:page]
    else
      @audits = []
    end
  end

  private

  def set_data
    @modules = ["Wishlist","Wallet","Vendor","Transaction","Room","Role","Review","PropertyType","Property",
      "Pricing","Location","ListingCategory","Listing","HouseRule","HouseCategory","Customer",
      "Coupon","Complaint","Cart","CarType","CarTransmission","CarSeat","CarFuelType","Car","Booking",
      "BlogCategory","Blog","Amenity","ActivityCategory","Activity","AccountDetail","User"
    ]

    @users = User.order(:name)
    @users_hash = @users.index_by(&:id)
  end
end