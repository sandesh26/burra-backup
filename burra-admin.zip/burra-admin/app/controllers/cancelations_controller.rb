class CancelationsController < ApplicationController
  before_action :set_cancelation, only: %i[ show edit update destroy ]

  def index
    policy_scope(Cancelation)
    @cancelations = Cancelation.includes(:order).page params[:page]
  end

  def show
    @customer = @cancelation.order.booking.customer
  end

  def new
    @cancelation = Cancelation.new
  end

  def edit
  end

  def create
    @cancelation = Cancelation.new(cancelation_params)

    authorize @cancelation
    respond_to do |format|
      if @cancelation.save
        format.html { redirect_to cancelation_url(@cancelation), notice: "Cancelation request was successfully created." }
        format.json { render :show, status: :created, location: @cancelation }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @cancelation.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    authorize @cancelation

    order = @cancelation.order
    refund_amt = order.listing_amt - order.shared_discount_amnt
    order = @cancelation.order
    order.update(status: 'canceled')
    customer = order.booking.customer
    payment_id = order.booking.payment_id

    respond_to do |format|
      if @cancelation.update(canceled: true, refunded: true, refund_amt: refund_amt)
      # if @cancelation
        # Phonepe.new.refund(@cancelation, customer, refund_amt, payment_id)
        # @cancelation.cancel_order
        format.html { redirect_to cancelation_url(@cancelation), notice: "Cancelation request was successfully updated." }
        format.json { render :show, status: :ok, location: @cancelation }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @cancelation.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    authorize @cancelation
    @cancelation.destroy!

    respond_to do |format|
      format.html { redirect_to cancelations_url, notice: "Cancelation request was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    def set_cancelation
      @cancelation = Cancelation.find(params[:id])
    end

    def cancelation_params
      params.fetch(:cancelation, {})
    end
end
