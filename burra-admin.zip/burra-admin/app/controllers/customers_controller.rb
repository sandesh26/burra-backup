class CustomersController < ApplicationController
  
  def index
    policy_scope(Customer)
    customers = Customer.verified.order(created_at: :desc)
    if params[:query].present?
      query = params[:query].gsub(/\s+/, "")
      results = customers.where("first_name ILIKE :query OR last_name ILIKE :query OR email ILIKE :query OR phone ILIKE :query", query: "%#{query}%")
      @customers = results.page params[:page]
    else
      @customers = customers.page params[:page]
    end
  end
  
end
