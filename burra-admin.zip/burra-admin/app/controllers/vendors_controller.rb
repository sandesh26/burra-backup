class VendorsController < ApplicationController
  before_action :set_vendor, only: %i[ show edit update destroy ]

  def index
    policy_scope(Vendor)
    vendors = Vendor.order(created_at: :desc)
    if params[:query].present?
      query = params[:query].gsub(/\s+/, "")
      results = vendors.where("first_name ILIKE :query OR last_name ILIKE :query OR email ILIKE :query OR phone ILIKE :query", query: "%#{query}%")
      @vendors = results.page params[:page]
    else
      @vendors = vendors.page params[:page]
    end
  end

  def show
    @bank_accounts = @vendor.account_details
  end

  def new
    @vendor = Vendor.new
  end

  def edit
  end

  def create
    @vendor = Vendor.new(vendor_params)

    respond_to do |format|
      if @vendor.save
        format.html { redirect_to vendors_url, notice: "Vendor was successfully created." }
        format.json { render :show, status: :created, location: @vendor }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @vendor.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @vendor.update(vendor_params)
        format.html { redirect_to vendors_url, notice: "Vendor was successfully updated." }
        format.json { render :show, status: :ok, location: @vendor }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @vendor.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    DeleteAccountJob.perform_now(@vendor.activity_ids)
    @vendor.destroy!

    respond_to do |format|
      format.html { redirect_to vendors_url, notice: "Vendor was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_vendor
      @vendor = Vendor.find_by(id: params[:id])
    end

    def vendor_params
      params.require(:vendor).permit(:first_name, :middle_name, :last_name, :phone, :email, :status, :documentid, :license, :document_type, account_details_attributes: [:id, :acc_holder_name, :branch_name, :email, :phone_number, :gst_number, :account_number, :ifsc_code, :bank_name, :_destroy])
    end
end
