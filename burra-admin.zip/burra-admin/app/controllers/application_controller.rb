class ApplicationController < ActionController::Base
  # include ActiveStorage::SetCurrent
  protect_from_forgery
  include Pundit::Authorization
  before_action :authenticate_user!
  before_action :set_paper_trail_whodunnit
  before_action :set_referrer_policy_header

  before_action do
    ActiveStorage::Current.url_options = { protocol: request.protocol, host: request.host, port: request.port }
  end

  # rescue_from Pundit::NotAuthorizedError do |exception|
  #   flash[:alert] = exception.message
  #   redirect_to(request.referrer || root_path)
  # end

  rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized

  private

  def user_not_authorized
    flash[:alert] = "You are not authorized to perform this action."
    if current_user && current_user.activity_manager?
      redirect_to(request.referrer || activities_path)
    else
      redirect_to(request.referrer || root_path)
    end
    # redirect_back(fallback_location: root_path)
  end

  def after_sign_in_path_for(resource)
    if resource.role.name == 'activity_manager'
      activities_path
    else
      root_path
    end
  end

  # private

  def set_referrer_policy_header
    response.headers['Referrer-Policy'] = 'same-origin'
  end

  def set_paper_trail_whodunnit
    PaperTrail.request.whodunnit = current_user&.id
  end

end