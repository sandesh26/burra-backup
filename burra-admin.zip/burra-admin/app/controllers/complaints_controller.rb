class ComplaintsController < ApplicationController
  before_action :set_complaint, only: %i[ show update ]

  def index
    policy_scope(Complaint)
    @complaints = Complaint.available.includes(:entity).page params[:page]
  end

  def show
    authorize @complaint
  end

  def update
    authorize @complaint
    respond_to do |format|
      if @complaint.update(status: params[:status], updated_by_id: current_user.id)
        format.html { redirect_to complaints_url, notice: "Complaint was marked as #{params[:status]}." }
        format.json { render :show, status: :ok, location: @complaint }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @complaint.errors, status: :unprocessable_entity }
      end
    end
  end

  private
  def set_complaint
    @complaint = Complaint.find_by(id: params[:id])
  end
end