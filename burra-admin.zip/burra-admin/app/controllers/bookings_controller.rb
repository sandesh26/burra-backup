require 'axlsx'

class BookingsController < ApplicationController
  include ApplicationHelper
  before_action :set_booking, only: %i[ show update cancel resend_booking_confirmation_email ]
  before_action :set_list, only: %i[ index ]

  def index
    policy_scope(Order)
    orders = Order.includes(:booking).not_initiated.order(created_at: :desc)
    if params[:entity_booking_id].present?
      @orders = orders.where(entity_booking_id: params[:entity_booking_id].gsub(/\s+/, "")).page params[:page]
    else
      @orders = orders.page params[:page]
    end
  end

  def show
    customer = Customer.find_by(id: @booking.customer_id)
    @customer_wallet = customer.wallet
    @bank_account = AccountDetail.find_by(id: @order.entity.account_detail_id)
  end

  def update
    respond_to do |format|
      if @booking.update(booking_params)
        format.html { redirect_to booking_url(@booking), notice: "Booking was successfully updated." }
        format.json { render :show, status: :ok, location: @booking }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @booking.errors, status: :unprocessable_entity }
      end
    end
  end

  def resend_booking_confirmation_email
    if @booking.email.present?
      email_only = true
      BookingConfirmationJob.perform_async(@booking.id, email_only)
      flash[:notice] = "Booking confirmation email has been sent!"
      redirect_to booking_path(@order.id)
    end
  end

  def cancel
    respond_to do |format|
      if @order.build_cancelation.save
        format.html { redirect_to booking_url(@order), notice: "Booking cancelation request created." }
        format.json { render :show, status: :ok, location: @booking }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @booking.errors, status: :unprocessable_entity }
      end
    end
  end

  def download
    if params[:activity_id].present?
      @activity = Activity.find_by(id: params[:activity_id])
      @orders = Order.where(entity: @activity)
    else
      @orders = Order.includes(:entity)
    end

    timestamp = Time.now.strftime("%d-%m-%Y")
    filename = "Bookings_report_#{timestamp}"

    respond_to do |format|
      format.xlsx {
        axlsx_package = Axlsx::Package.new
        axlsx_package.workbook.add_worksheet(name: filename) do |sheet|
          # Add headers
          if @activity.nil?
            sheet.add_row ['ID', 'Activity Name', 'Booking ID']

            # Add data rows
            @orders.each do |order|
              sheet.add_row [order.id.to_s, order.entity.name, order.entity_booking_id]
            end
          else
            sheet.add_row ['ID', 'Booking ID']

            # Add data rows
            @orders.each do |order|
              sheet.add_row [order.id.to_s, order.entity_booking_id]
            end
          end
        end

        # Send the generated file to the user
        send_data axlsx_package.to_stream.read, filename: "#{filename}.xlsx", type: "application/xlsx", disposition: 'attachment'
      }
    end
  end

  private
    def set_booking
      @order = Order.find_by(id: params[:id])
      @booking = Booking.find_by(id: @order.booking_id)
      if @booking.nil? || @order.nil?
        redirect_to bookings_path
      end
    end

    def set_list
      @activities = Activity.approved
    end

    def booking_params
      params.require(:booking).permit(:entity, :customer_id, :order_id, :wallet_used, :wallet_amount_used, :subtotal, :coupon_id, :discount, :discount_amount, :tax_fees, :total_amt, :listing_amount, :status, :payment_gateway_data)
    end
end
