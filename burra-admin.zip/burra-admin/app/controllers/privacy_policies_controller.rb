class PrivacyPoliciesController < ApplicationController
  before_action :set_policy
  def index
    if @privacy_policy.nil?
      @privacy_policy = PrivacyPolicy.create(content: '')
      redirect_to edit_privacy_policy_path(@privacy_policy)
    else
      render :index
    end
  end

  def edit
  end

  def update
    authorize @privacy_policy
    @privacy_policy.update(privacy_policy_params)
    @privacy_policy.save
    redirect_to privacy_policies_path, notice: 'Privacy Policy updated!'
  end

  private

  def set_policy
    @privacy_policy = PrivacyPolicy.first
  end

  def privacy_policy_params
    params.require(:privacy_policy).permit(:content)
  end
end
