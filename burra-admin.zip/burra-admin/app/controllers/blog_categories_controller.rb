class BlogCategoriesController < ApplicationController
  before_action :set_blog_category, only: %i[ show edit update destroy ]

  def index
    policy_scope(BlogCategory)
    @blog_categories = BlogCategory.order(:title).page params[:page]
  end

  def show
  end

  def new
    @blog_category = BlogCategory.new
  end

  def edit
  end

  def create
    @blog_category = BlogCategory.new(blog_category_params)

    authorize @blog_category
    respond_to do |format|
      if @blog_category.save
        format.html { redirect_to blog_categories_url, notice: "Blog category was successfully created." }
        format.json { render :show, status: :created, location: @blog_category }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @blog_category.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    authorize @blog_category
    respond_to do |format|
      if @blog_category.update(blog_category_params)
        format.html { redirect_to blog_categories_url, notice: "Blog category was successfully updated." }
        format.json { render :show, status: :ok, location: @blog_category }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @blog_category.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    authorize @blog_category
    @blog_category.delete

    respond_to do |format|
      format.html { redirect_to blog_categories_url, notice: "Blog category was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_blog_category
      @blog_category = BlogCategory.find(params[:id])
    end

    def blog_category_params
      params.require(:blog_category).permit(:title, :status)
    end
end
