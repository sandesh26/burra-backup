class ActivitiesController < ApplicationController
  before_action :set_activity, only: %i[ show edit update destroy ]
  before_action :set_list, except: %i[ index ]
  before_action :set_list_hash, only: %i[ index show pending ]

  def index
    policy_scope(Activity)
    @activities = Activity.approved.order(created_at: :desc).page params[:page]
  end

  def pending
    policy_scope(Activity)
    @pending_activities = Activity.pending.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @activity = Activity.new
    @activity.packages.build
    @activity.packages.first.package_types.build
    @activity.packages.first.package_types.first.slots.build
  end

  def edit
    if @activity.packages.blank?
      @activity.packages.build
      @activity.packages.first.package_types.build
      @activity.packages.first.package_types.first.slots.build
    end
  end

  def create
    @activity = Activity.new(activity_params)
    authorize @activity
    
    respond_to do |format|
      if @activity.save
        if @activity.status == 'approved'
          NotificationsJob.perform_async('customer', 'New Activity Available!', @activity.name.truncate(100, omission: '...'), 'TourDetails', @activity.id.to_s)
        end
        format.html { redirect_to activity_url(@activity), notice: "Activity was successfully created." }
        format.json { render :show, status: :created, location: @activity }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    authorize @activity
    respond_to do |format|
      if @activity.status != 'approved' && activity_params[:status] == 'approved'
        NotificationsJob.perform_async('customer', 'New Activity Available!', @activity.name.truncate(100, omission: '...'), 'TourDetails', @activity.id.to_s)
      end
      if @activity.update(activity_params.reject { |k| k["files"] })
        if activity_params[:files].present?
         activity_params[:files].each do |file|
           @activity.files.attach(file)
         end
        end
        unless params[:deleted_file_ids].blank?
          files = ActiveStorage::Attachment.where(id: params[:deleted_file_ids])
          files.map(&:purge)
        end
        format.html { redirect_to activity_url(@activity), notice: "Activity was successfully updated." }
        format.json { render :show, status: :ok, location: @activity }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    authorize @activity
    # @activity.update!(is_deleted: true)
    entity = @activity
    Wishlist.where(entity: entity).destroy_all
    Item.where(entity: entity).destroy_all
    booking_ids = Order.where(entity: entity).pluck(:booking_id)
    unless booking_ids.blank?
      bookings = Booking.where(id: booking_ids).destroy_all
    end
    @activity.destroy

    respond_to do |format|
      format.html { redirect_back fallback_location: root_path, notice: "Activity was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_activity
      @activity = Activity.friendly.find(params[:id])
    end

    def set_list
      @categories = ActivityCategory.active
      @locations = Location.order(created_at: :desc)
      @vendors = Vendor.order(:first_name)
    end

    def set_list_hash
      @categories_hash = ActivityCategory.active.index_by(&:id)
    end

    def activity_params
      params.require(:activity).permit(:name, :description, :min_person_allowed, :max_person_allowed, :status, :vendor_price, :actual_price, :discounted_price, :is_deleted, :start_date, :start_time, :end_time, :booking_paused_until, :vendor_id, :account_detail_id, :latitude, :longitude, :address, :location_id, :meta_description, :meta_keywords, :meta_title, :prior_booking, packages_attributes: [:id, :title, :details, :_destroy, package_types_attributes: [:id, :title, :details, :price, :vendor_price, :offer_price, :_destroy, slots_attributes: [:id, :quantity, :date, :_destroy]]], :activity_category_ids => [], :files => [])
    end
end