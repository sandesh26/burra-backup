class CarSeatsController < ApplicationController
  before_action :set_car_seat, only: %i[ show edit update destroy ]

  def index
    @car_seats = CarSeat.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @car_seat = CarSeat.new
  end

  def edit
  end

  def create
    @car_seat = CarSeat.new(car_seat_params)

    respond_to do |format|
      if @car_seat.save
        format.html { redirect_to car_seats_url, notice: "Car seat was successfully created." }
        format.json { render :show, status: :created, location: @car_seat }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @car_seat.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @car_seat.update(car_seat_params)
        format.html { redirect_to car_seats_url, notice: "Car seat was successfully updated." }
        format.json { render :show, status: :ok, location: @car_seat }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @car_seat.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @car_seat.destroy!

    respond_to do |format|
      format.html { redirect_to car_seats_url, notice: "Car seat was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    def set_car_seat
      @car_seat = CarSeat.find(params[:id])
    end

    def car_seat_params
      params.require(:car_seat).permit(:name, :status)
    end
end
