class CarsController < ApplicationController
  before_action :set_car, only: %i[ show edit update destroy ]
  before_action :set_list, except: %i[ index ]

  def index
    _cars = Car.available.includes(:car_fuel_type, :car_type, :car_transmission, :car_seat).order(created_at: :desc)
    if params[:listing_id]
      @cars = _cars.where(listing_id: params[:listing_id]).page params[:page]
    else
      @cars = _cars.page params[:page]
    end
  end

  def show
  end

  def new
    @car = Car.new
  end

  def edit
  end

  def create
    @car = Car.new(car_params)

    respond_to do |format|
      if @car.save
        format.html { redirect_to listing_car_url(@listing, @car), notice: "Car was successfully created." }
        format.json { render :show, status: :created, location: @car }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @car.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @car.update(car_params.reject { |k| k["files"] })
        if car_params[:files].present?
         car_params[:files].each do |file|
           @car.files.attach(file)
         end
        end
        unless params[:deleted_file_ids].blank?
          files = ActiveStorage::Attachment.where(id: params[:deleted_file_ids])
          files.map(&:purge)
        end
        format.html { redirect_to listing_car_url(@listing, @car), notice: "Car was successfully updated." }
        format.json { render :show, status: :ok, location: @car }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @car.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @car.update!(is_deleted: true)

    respond_to do |format|
      format.html { redirect_back fallback_location: root_path, notice: "Car was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_car
      @car = Car.find_by(id: params[:id])
    end

    def set_list
      @listing = Listing.find_by(id: params[:listing_id])
      @car_fuel_types = CarFuelType.active.order(created_at: :desc)
      @car_types = CarType.active.order(created_at: :desc)
      @car_seats = CarSeat.active.order(created_at: :desc)
      @car_transmissions = CarTransmission.active.order(created_at: :desc)
    end

    def car_params
      params.require(:car).permit(:name, :description, :car_type_id, :car_seat_id, :status, :car_fuel_type_id, :car_transmission_id, :actual_price, :discounted_price, :listing_id, :is_deleted, :files => [])
    end
end