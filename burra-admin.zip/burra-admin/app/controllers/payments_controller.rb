class PaymentsController < ApplicationController
  skip_before_action :authenticate_user!
  skip_before_action :verify_authenticity_token

  def success
    @booking = Booking.find_by(parent_booking_id: params[:transactionId])

    if Rails.env == 'development'
      redirect_url = 'http://localhost:3001'
    else
      redirect_url = 'https://burraa.com'
    end
    if @booking.present? and params[:providerReferenceId].present? and params[:code] == 'PAYMENT_SUCCESS'
      @booking.update(payment_id: params[:providerReferenceId])

      coins = [@booking.paid_amt * 0.01, 50].min.round
      orders = @booking.orders
      orders.update_all(status: 'confirmed')
      customer = @booking.customer
      wallet = customer.wallet
      # BookingConfirmationJob.perform_async(@booking.id)

      wallet = wallet.increment!(:balance, coins)
      wallet.transactions.build(transaction_type: 'add', amount: coins)
      wallet.save

      orders.each do |order|
        vendor = order.vendor
        v_wallet = vendor.wallet
        v_wallet.increment!(:balance, order.earned_amt)
        v_wallet.transactions.build(transaction_type: 'add', amount: order.earned_amt)
        v_wallet.save
      end

      customer.wishlists.where(entity_id: orders.pluck(:entity_id)).delete_all
      customer.cart.items.delete_all
      sleep 1
      BookingConfirmationJob.perform_async(@booking.id)
      # orders.each do |order|
      #   VendorMailer.with(order: order).booking_received_email.deliver_now
      #   CustomerMailer.with(order: order).booking_confirmation_email.deliver_now
      # end
      redirect_to redirect_url+'/db-booking', allow_other_host: true
    else
      redirect_to redirect_url, allow_other_host: true
    end
  end
end
