class ReviewsController < ApplicationController
  # has_paper_trail
  before_action :set_review, only: %i[ show edit update destroy ]
  before_action :set_activities, only: %i[ edit update new create ]

  def index
    policy_scope(Review)
    # @reviews = Review.available.includes(:entity).page params[:page]
    @reviews = Review.includes(:entity).page params[:page]
  end

  def new
    @review = Review.new  
  end

  def show
    authorize @review
  end

  def edit
  end

  def create
    @review = Review.new(review_params)
    authorize @review
    respond_to do |format|
      if @review.save
        format.html { redirect_to review_url(@review), notice: "Review was successfully created." }
        format.json { render :show, status: :created, location: @review }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @review.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    authorize @review
    respond_to do |format|
      if @review.update(review_params)
        format.html { redirect_to reviews_url, notice: "Review was successfully updated." }
        format.json { render :show, status: :ok, location: @review }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @review.errors, status: :unprocessable_entity }
      end
    end
  end

   def destroy
    authorize @review
    @review.destroy!

    respond_to do |format|
      format.html { redirect_to reviews_url, notice: "Review was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
  def set_review
    @review = Review.find_by(id: params[:id])
  end

  def set_activities
    @activities = Activity.approved
  end

  def review_params
    params.require(:review).permit(:comment, :star, :entity_id, :entity_type, :customer, :is_approved)
  end
end
