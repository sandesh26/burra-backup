class CouponsController < ApplicationController
  before_action :set_coupon, only: %i[ show edit update destroy ]
  before_action :get_customers, only: %i[ edit update new ]

  def index
    policy_scope(Coupon)
    @coupons = Coupon.order(:title).page params[:page]
  end

  def new
    @coupon = Coupon.new  
  end

  def show
    authorize @coupon
  end

  def edit
  end

  def update
    authorize @coupon
    respond_to do |format|
      if @coupon.update(coupon_params)
        format.html { redirect_to coupon_url(@coupon), notice: "Coupon was successfully updated." }
        format.json { render :show, status: :ok, location: @coupon }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @coupon.errors, status: :unprocessable_entity }
      end
    end
  end

  def create
    @coupon = Coupon.new(coupon_params)
    authorize @coupon
    respond_to do |format|
      if @coupon.save
        NotificationsJob.perform_async('customer', @coupon.title, "Use #{@coupon.coupon_code} to avail the Offer!", 'OfferDetails', @coupon.id.to_s) if @coupon.common
        format.html { redirect_to coupon_url(@coupon), notice: "Coupon was successfully created." }
        format.json { render :show, status: :created, location: @coupon }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @coupon.errors, status: :unprocessable_entity }
      end
    end
  end

   def destroy
    authorize @coupon
    @coupon.destroy!

    respond_to do |format|
      format.html { redirect_to coupons_url, notice: "Coupon was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
  def set_coupon
    @coupon = Coupon.find(params[:id])
  end

  def get_customers
    @customers = Customer.all
  end

  def coupon_params
    params.require(:coupon).permit(:title, :description, :min_cart_val, :coupon_code, :valid_from, :valid_till, :status, :common, :discounted, :customer_id, :image)
  end
end
