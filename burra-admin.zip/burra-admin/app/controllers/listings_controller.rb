class ListingsController < ApplicationController
  before_action :set_listing, only: %i[ show edit update destroy ]
  before_action :set_list, only: %i[ new edit create update ]

  def index
    @listings = Listing.available.includes(:listing_category, :vendor, :location).order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @listing = Listing.new
  end

  def edit
  end

  def create
    @listing = Listing.new(listing_params)

    respond_to do |format|
      if @listing.save
        format.html { redirect_to listing_url(@listing), notice: "Listing was successfully created." }
        format.json { render :show, status: :created, location: @listing }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @listing.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @listing.update(listing_params)
        if @listing.status == 'suspended'
          @listing.activities.update(status: @listing.status)
        end
        format.html { redirect_to listing_url(@listing), notice: "Listing was successfully updated." }
        format.json { render :show, status: :ok, location: @listing }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @listing.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @listing.update!(is_deleted: true)
    DeleteListingJob.perform_now(@listing.id)

    respond_to do |format|
      format.html { redirect_to listings_url, notice: "Listing was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_listing
      @listing = Listing.find_by(id: params[:id])
    end

    def set_list
      @locations = Location.order(created_at: :desc)
      @listing_categories = ListingCategory.order(created_at: :desc)
      @vendors = Vendor.order(:first_name)
    end

    def listing_params
      params.require(:listing).permit(:title, :description, :latitude, :longitude, :address, :status, :location_id, :is_deleted, :vendor_id, :listing_category_id, :account_detail_id, :meta_description, :meta_keywords, :meta_title, :documentid)
    end
end