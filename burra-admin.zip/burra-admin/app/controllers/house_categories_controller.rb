class HouseCategoriesController < ApplicationController
  before_action :set_house_category, only: %i[ show edit update destroy ]

  def index
    @house_categories = HouseCategory.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @house_category = HouseCategory.new
  end

  def edit
  end

  def create
    @house_category = HouseCategory.new(house_category_params)

    respond_to do |format|
      if @house_category.save
        format.html { redirect_to house_categories_url, notice: "Category was successfully created." }
        format.json { render :show, status: :created, location: @house_category }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @house_category.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @house_category.update(house_category_params)
        format.html { redirect_to house_categories_url, notice: "Category was successfully updated." }
        format.json { render :show, status: :ok, location: @house_category }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @house_category.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @house_category.destroy!

    respond_to do |format|
      format.html { redirect_to house_categories_url, notice: "Category was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_house_category
      @house_category = HouseCategory.find(params[:id])
    end

    def house_category_params
      params.require(:house_category).permit(:name, :status, :image)
    end
end
