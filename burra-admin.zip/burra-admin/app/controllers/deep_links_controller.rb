class DeepLinksController < ApplicationController
  before_action :set_deep_link, only: %i[ show edit update destroy ]

  def index
    policy_scope(DeepLink)
    @deep_links = DeepLink.order(created_at: :desc).page params[:page]
  end

  def show
    authorize @deep_link
  end

  def new
    @deep_link = DeepLink.new
  end

  def edit
  end

  def create
    @deep_link = DeepLink.new(deep_link_params)
    authorize @deep_link
    respond_to do |format|
      if @deep_link.save
        format.html { redirect_to @deep_link, notice: "Deep link was successfully created." }
        format.json { render :show, status: :created, location: @deep_link }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @deep_link.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    authorize @deep_link
    respond_to do |format|
      if @deep_link.update(deep_link_params)
        format.html { redirect_to @deep_link, notice: "Deep link was successfully updated." }
        format.json { render :show, status: :ok, location: @deep_link }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @deep_link.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    authorize @deep_link
    @deep_link.destroy!

    respond_to do |format|
      format.html { redirect_to deep_links_path, status: :see_other, notice: "Deep link was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    def set_deep_link
      @deep_link = DeepLink.friendly.find(params[:id])
    end

    def deep_link_params
      params.require(:deep_link).permit(:title, :internal_link, :external_link, :keywords, :description)
    end
end
