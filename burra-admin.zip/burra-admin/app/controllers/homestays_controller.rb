class HomestaysController < ApplicationController
  def index
    @rooms = Room.order(created_at: :desc).page params[:page]
  end

  def show
    # @room = Room.find_by(id: params[:id])
  end
end
