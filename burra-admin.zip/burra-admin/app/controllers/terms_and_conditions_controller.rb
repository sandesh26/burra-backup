class TermsAndConditionsController < ApplicationController
  before_action :set_terms

  def index
    if @terms_and_condition.nil?
      @terms_and_condition = TermsAndCondition.create(content: '')
      redirect_to edit_terms_and_condition_path(@terms_and_condition)
    else
      render :index
    end
  end

  def edit
  end

  def update
    authorize @terms_and_condition
    @terms_and_condition.update(terms_and_condition_params)
    @terms_and_condition.save
    redirect_to terms_and_conditions_path, notice: 'Terms & Conditions updated!'
  end

  private

  def set_terms
    @terms_and_condition = TermsAndCondition.first
  end

  def terms_and_condition_params
    params.require(:terms_and_condition).permit(:content)
  end
end
