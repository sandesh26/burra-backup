module Api
  module V1
    class AuthenticationController < ApiController
      skip_before_action :authenticate_request!

      def authenticate_user
        user = find_user(params[:entity_type], params[:phone], params[:email])

        if user && user.verification_code == params[:verification_code]
          user.update(verification_code: nil, status: 'verified')
          if params[:fcmToken].present?
            existing_token = DeviceToken.where('token =? and client_type =?', params[:fcmToken], params[:entity_type].capitalize).first
            if existing_token.nil?
              user.device_tokens.build(token: params[:fcmToken]).save
            else
              existing_token.update(client: user)
            end
          end
          user.sync_user_cart(params[:userId]) if params[:entity_type].capitalize == 'Customer'
          json_response(payload(user))
        else
          render json: { errors: 'Enter correct OTP' }
        end
      end

      def generate_otp
        user = find_user(params[:entity_type], params[:phone], params[:email])
        otp_number = params[:entity_type].capitalize == 'Customer' ? params[:verification_code] : 639820
        # otp_number = params[:verification_code]
        if user.update(verification_code: otp_number)
          if params[:email].present?
            if Rails.env == 'production'
              VerificationCodeJob.perform_async(user.id)
            end
          else
            if Rails.env == 'production'
              Sms.new(params[:phone], otp_number).send_otp
            end
          end
          render json: { status: :ok }
        else
          render json: { errors: user.errors.full_messages.to_sentence }
        end
      end

      def sign_up
        if params[:type].present?
          user = find_user(params[:entity_type], '', params[:email])
          user.grab_image(params[:profileImgUrl]) unless user.image.attached?
          user.social = 'Google'
        else
          user = find_user(params[:entity_type], params[:phone], params[:email])
        end

        if user.persisted? && params[:type].nil?
          return render json: { errors: 'An account with this email already exists. Please log in or use a different email.' }
        end

        user.assign_attributes(password: params[:password], email: params[:email], first_name: params[:firstName], last_name: params[:lastName])

        # if user.verification_code == params[:verification_code]
        if user.save
          if params[:fcmToken].present?
            existing_token = DeviceToken.where('token =? and client_type =?', params[:fcmToken], params[:entity_type].capitalize).first
            if existing_token.nil?
              user.device_tokens.build(token: params[:fcmToken]).save
            else
              existing_token.update(client: user)
            end
          end
          json_response payload(user)
        else
          render json: { errors: user.errors.full_messages.to_sentence }
        end
        # else
        #   render json: { errors: 'Enter correct OTP' }
        # end
      end

      def sign_in
        user = find_user('customer', '', params[:email])
        if user && user.id
          if user.password == params[:password]
            # user.device_tokens.build(token: params[:fcmToken]).save
            json_response payload(user)
          else
            render json: { errors: 'Incorrect password', status: 422 }
          end
        else
          render json: { errors: 'User not found.', status: 422 }
        end
      end

      def forgot
        user = find_user('customer', '', params[:email])
        if params[:verification_code].present? && user.verification_code == params[:verification_code]
          user.update(verification_code: nil)
          return render json: { success: 'ok' }
        end
        if user.persisted?
          code = user.new_otp
          user.update(verification_code: code)
          CustomerMailer.with(user: user).reset_password_email.deliver_later
          render json: { message: 'A vertification code has been sent to your email.' }
        else
          render json: { errors: 'No account found with this email. Please sign up or use a different email.'}
        end
      end

      def change_password
        user = find_user('customer', '', params[:email])
        if user
          user.update(password: params[:password])
          CustomerMailer.with(user: user).changed_password_email.deliver_later
        else
          render json: { errors: user.errors.full_messages.to_sentence }
        end
        json_response payload(user)
      end

      def sync_device_token
        device_token = DeviceToken.new(
          client_type: params[:entity_type].capitalize, token: params[:fcmToken]
        )
        device_token.save
        render json: :ok
      end

      private

      def payload(user)
        return nil unless user and user.id
        user.increment!(:sign_in_count, 1)
        {
          user: {
            id: user.id, 
            email: user.email || '',
            phone: user.phone || '',
            first_name: user.first_name || '',
            last_name: user.last_name || '',
            onboarding: user.class.name == 'Customer' ? 'N/A' : !user.activities.blank?,
            license: (user.class.name == 'Vendor' && user.license.attached?) ? { uri: user.license.url } : '',
            documentId: (user.class.name == 'Vendor' && user.documentid.attached?) ? { uri: user.documentid.url } : '',
            documentType: user.class.name == 'Vendor' ? user.document_type : 'N/A',
            auth_token: encode_token(user),
            profileImg: { uri: user.image.attached? ? url_for(user.image) : nil },
            signInCount: user.sign_in_count
          }
        }
      end

      def encode_token(user)
        if user.phone.present?
          JsonWebToken.encode({ phone: user.phone })
        else
          JsonWebToken.encode({ email: user.email })
        end
      end

      def find_user(entity_type, phone=nil, email=nil)
        _class_name = entity_type.capitalize
        klass = Object.const_get _class_name
        if phone.present?
          _user = klass.find_or_initialize_by(phone: phone)
        else
          _user = klass.find_or_initialize_by(email: email)
        end
        _user
      end
    end
  end
end