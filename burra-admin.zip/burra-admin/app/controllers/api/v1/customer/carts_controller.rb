module Api
  module V1
    module Customer
      class CartsController < ApiController

        def items
          @cart = current_customer.cart
          @cart_items = @cart ? @cart.items.includes(entity: { files_attachments: :blob }) : []
          package_type_ids = @cart.items.pluck(:package_type_id)
          @package_types = PackageType.where(id: package_type_ids)
          @packages = Package.where(id: @package_types.pluck(:package_id)).index_by(&:id)
          @package_types_indexed = @package_types.index_by(&:id)
        end

        def create
          @cart = Cart.find_or_create_by(customer_id: current_customer.id)
          cart_items = @cart.items
          @entity = Item.get_entity(params[:entity_id], params[:entity_type])
          selected_date = @entity.start_date.present? ? @entity.start_date : Date.parse(params[:selectedDate])
          selected_slots = params[:quantity].present? ? params[:quantity].to_i : 1

          is_adding_to_cart = true
          available = Item.check_availability(selected_date, @entity, @cart, params[:packageTypeId], selected_slots, is_adding_to_cart)
          success = true

          if available[:response] == true
            selected_slots.times do
              @item = cart_items.build
              @item.entity = @entity
              @item.package_type_id = params[:packageTypeId]
              @item.selected_date = selected_date
              success = @item.save && success
            end
            if success
              render json: { status: :ok }
            else
              render json: { errors: @item.errors.full_messages.to_sentence }
            end
          else
            render json: { errors: available[:pt_message] }
          end
          rescue ActiveRecord::NotNullViolation
            render json: { errors: "null or missing params" }, status: 400
        end

        def item_available
          @cart = current_customer.cart
          @cart_items = @cart ? @cart.items : []

          errors = {}

          booking_data = params["bookingData"].transform_keys(&:to_sym)
          order_details = booking_data[:orderDetails]

          order_details.each do |entity_id, entities|
            __id = entity_id.split('_')[0]
            entity = Activity.find_by(id: __id)

            entities.each do |index, order|
              date = Date.parse(order[:checkInDate])
              available = Item.check_availability(date, entity, @cart, order[:packageTypeId], order[:quantity].to_i)
              if available[:response] == false
                errors["pt_#{order[:packageTypeId]}"] = available[:pt_message]
              end
            end
          end

          if errors.present?
            render json: { errors: errors }
          else
            render json: { status: :ok }
          end
        end

        def razorpay_order_id
          amount = params[:amount]
          order = Razorpay.new.create_order(amount)
          if order["id"].present?
            render json: { order_id: order["id"] }
          else
            render json: { errors: "An error occurred while processing your request. Please try again later." }
          end
        end

        def initiate_payment
          payment_url = Phonepe.new.get_payment_url(params, current_customer)
          render json: payment_url
        end

        def checkout
          Item.checkout(params, current_customer, params["merchantTransactionId"])
          render json: :ok
        end

        def destroy
          ActiveRecord::Base.transaction do
            if params[:multiRemove] == '1'
              @cart_items = current_customer.cart.items.where(entity_id: params[:entityId], package_type_id: params[:packageTypeId], selected_date: Date.parse(params[:date]))
            else
              @cart_items = current_customer.cart.items.where(id: params[:id])
            end
            if @cart_items.length > 0
              @cart_items.delete_all
              render json: { status: :ok }
            else
              render json: { status: :not_found }
            end
          end
        end

      end
    end
  end
end