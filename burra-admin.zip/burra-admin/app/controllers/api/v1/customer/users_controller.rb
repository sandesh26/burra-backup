module Api
  module V1
    module Customer
      class UsersController < ApiController
        before_action :set_order, only: %i[ order_details cancel_request ]

        def wallet
          @wallet = current_customer.wallet
          json_response(@wallet)
        end

        def bookings
          booking_ids = current_customer.bookings.joins(:orders).where.not(orders: { status: 'deleted' }).ids
          order_ids = Order.where(booking_id: booking_ids).ids
          entity_ids = Order.where(booking_id: booking_ids).pluck(:entity_id)
          result = Booking.categorize_bookings(current_customer, order_ids, entity_ids)
          render json: result
        end

        def order_details
        end

        def resend_booking_confirmation_email
          @order = Order.find_by(id: params[:order_id])
          @booking = @order.booking

          if @booking && @booking.email.present?
            email_only = true
            BookingConfirmationJob.perform_async(@booking.id, email_only)
            render json: :ok
          end
        end

        def add_review
          entity = Activity.find_by(id: params[:id])
          review = Review.create(
            entity: entity,
            star: params[:star],
            customer: current_customer.id,
            comment: params[:comment],
            order_id: params[:order_id],
            is_approved: params[:comment].nil?
          )
          render json: :ok
        end

        def reviews
          reviews = Review.where(customer: current_customer.id.to_s)
          render json: reviews
        end

        def cancel_request
          @order.build_cancelation.save
          render json: :ok
        end

        def update
          klass = Object.const_get 'Customer'
          user = klass.find_by(id: params[:id]) || current_customer


          if params[:file].present?
            user.image = params[:file]
          end
          if params[:verification_code].present?
            if user.verification_code == params[:verification_code]
              user.update(verification_code: nil)
            else
              return render json: { errors: 'Enter correct OTP' }
            end
          end


          if user.update(email: params[:email], phone: params[:phone], first_name: params[:firstName], last_name: params[:lastName])
            json_response(user:
              { id: user.id,
                email: user.email || '',
                phone: user.phone || '',
                first_name: user.first_name || '',
                last_name: user.last_name || '',
                auth_token: encode_token(user),
                profileImg: { uri: user.image.attached? ? url_for(user.image) : nil },
                updated_at: user.updated_at,
                signInCount: user.sign_in_count
              })
          else
            render json: { errors: user.errors.full_messages.to_sentence }
          end
        end

        def request_otp
          klass = Object.const_get 'Customer'

          user = klass.find_by(id: params[:id]) || current_customer

          otp_number = params[:verification_code]
          phone = params[:phone]
          email = params[:email]

          if phone.present?
            existing_user = klass.find_by(phone: phone)
            if existing_user && existing_user.id != user.id
              return render json: { errors: "This phone number is linked with another account. Please try with different phone number" }
            end
          end

          if email.present?
            existing_user = klass.find_by(email: email)
            if existing_user && existing_user.id != user.id
              return render json: { errors: "This email number is linked with another account. Please try with different email number" }
            end
          end


          if user.update(verification_code: otp_number)
            if params[:email].present?
              VerificationCodeJob.perform_async(user.id)
            else
              Sms.new(params[:phone], otp_number).send_otp
            end
            render json: :ok
          else
            render json: { errors: user.errors.full_messages.to_sentence }
          end
        end

        def delete_account
          if current_customer && current_customer.verification_code == params[:verification_code]
            current_customer.destroy
            render json: { status: :ok }
          else
            render json: { errors: 'Enter correct OTP' }
          end
        end


        private

        def set_order
          @order = {}
          c_bookings = current_customer.bookings
          _order = Order.find_by(id: params[:order_id])
          if _order.present?
            booking_id = _order.booking_id
            booking = c_bookings.find_by(id: booking_id)
            if booking.present?
              @order = booking.orders.find_by(id: _order.id)
            end
          end
        end

        def encode_token(user)
          if user.phone.present?
            JsonWebToken.encode({ phone: user.phone })
          else
            JsonWebToken.encode({ email: user.email })
          end
        end

      end
    end
  end
end
