module Api
  module V1
    module Customer
      class WishlistsController < ApiController

        def index
          wishlists = Wishlist.where(customer_id: current_customer.id)
          _wishlists = wishlists.order(created_at: :desc).group_by(&:entity_type)

          @wishlists = _wishlists.map do |entity_type, wishlists|
            {
              title: entity_type == 'Room' ? 'Homestay' : entity_type,
              data: wishlists.map { |wishlist| {
                id: wishlist.id, 
                title: wishlist.entity.name,
                entity_id: wishlist.entity_id,
                description: wishlist.entity.description,
                primary_image: wishlist.entity.files.attached? ? wishlist.entity.files[0].url : nil,
                vendor_id: wishlist.entity.vendor_id,
                ratings: wishlist.entity.reviews.average(:star).to_f,
                reviews: wishlist.entity.reviews.length,
                address: wishlist.entity.address,
                activity_category_ids: wishlist.entity.activity_category_ids,
                actualPrice: wishlist.entity.actual_price,
                discountedPrice: wishlist.entity.discounted_price
                } 
              }
            }
          end
          render json: @wishlists
        end

        def create
          @wishlist = current_customer.wishlists.build
          wishlist = current_customer.wishlists.where('entity_type =? and entity_id =?', params[:entity_type], params[:entity_id]).first
          if wishlist.nil?
            @wishlist.entity_id = params[:entity_id]
            @wishlist.entity_type = params[:entity_type]
          end
          
          if wishlist.present? ? wishlist.delete : @wishlist.save
            render json: { wishlist: @wishlist, status: :ok }
          else
            render json: { errors: @wishlist.errors, status: :unprocessable_entity }
          end
          rescue ActiveRecord::NotNullViolation
            render json: { errors: "null or missing params" }, status: 400
        end

        def destroy
          @wishlist = current_customer.wishlists.find_by(id: params[:id])
          if @wishlist and @wishlist.destroy
            render json: { status: :ok }
          else
            render json: { status: :not_found }
          end
        end

      end
    end
  end
end