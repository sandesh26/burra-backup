module Api
  module V1
    module Customer
      class BlogsController < ApiController
        skip_before_action :authenticate_request!

        def index
          blogs = Blog.includes(cover_image_attachment: :blob).joins(:blog_category).order(:title)
          if params[:category_id]
            @blogs = blogs.where(blog_category_id: params[:category_id])
          else
            @blogs = blogs
          end
        end

        def show
          @blog = Blog.friendly.find(params[:id])
        end

        def categories
          @categories = BlogCategory.joins(:blogs).distinct.order(:title)
        end

      end
    end
  end
end