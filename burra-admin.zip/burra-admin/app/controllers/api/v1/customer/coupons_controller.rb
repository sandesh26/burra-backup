module Api
  module V1
    module Customer
      class CouponsController < ApiController

        def index
          used_coupons = get_used_coupons
          @coupons = Coupon.includes(image_attachment: :blob).includes(:rich_text_description).order(:min_cart_val).where.not(id: used_coupons).where('valid_from <= ? AND valid_till >= ?', Date.today, Date.today).active.common
        end

        def show
          @coupon = Coupon.find_by(id: params[:id])
        end

        def get_used_coupons
          current_customer ? current_customer.bookings.where.not(payment_id: nil).pluck(:coupon_id) : []
        end

        def verify_coupon
          used_coupons = get_used_coupons
          @coupon = Coupon.find_by(coupon_code: params[:coupon_code].gsub(/\s+/, ""))
          if @coupon && used_coupons.include?(@coupon.id)
            render json: { message: "You already have used this coupon.", status: :ok }
          elsif @coupon and !@coupon.common and @coupon.valid_from <= Date.today and @coupon.valid_till >= Date.today
            render json: @coupon
          else
            render json: :not_found
          end
        end

      end
    end
  end
end