module Api
  module V1
    module Customer
      class ContentController < ApiController
        skip_before_action :authenticate_request!

        def terms
          @terms = TermsAndCondition.last.content.body
          render json: @terms
        end

        def policy
          @policy = PrivacyPolicy.last.content.body
          render json: @policy
        end

        def refund_policy
          @refund_policy = CancellationPolicy.last.content.body
          render json: @refund_policy
        end

      end
    end
  end
end