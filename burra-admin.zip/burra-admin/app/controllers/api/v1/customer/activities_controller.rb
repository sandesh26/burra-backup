module Api
  module V1
    module Customer
      class ActivitiesController < ApiController
        before_action :set_wishlists, :set_cart_items, only: %i[ index homestays cars show similar events ]

        def index
          activities = Activity.includes(files_attachments: :blob)
          @activities = activities.search(params)

          @activity_data = get_wishlists_and_cart_items("Activity")
          @activity_wishlists = @activity_data[:wishlists]
          @activity_cart_items = @activity_data[:cart_items]
          _filter_date = params.dig(:filter_by, :filterDate).to_s
          @filter_date = _filter_date.present? ? Date.parse(_filter_date) : Date.today
          
          old_events = @activities.where('start_date < ?', Date.today)
          not_expired = activities.approved.not_expired

          if _filter_date.present?
            _activities = activities.approved.includes(:reviews, :orders)._filter_by_date(_filter_date)
            @activities = (_activities + @activities)
          end

          acts = (@activities - old_events) + not_expired
          if params[:searchStr]
            str = params[:searchStr]
            acts = acts.select { |act| act.name.downcase.include?(str.downcase) }
          end
          if params[:mapView] == 'true' || params[:page].nil?
            @activities = acts.uniq
            @total_count = @activities.length
          else
            @total_count = acts.uniq.length
            page = params[:page].to_i > 0 ? params[:page].to_i : 1
            @activities = Kaminari.paginate_array(acts.uniq).page(page).per(10)
          end
        end

        def similar
          activities = Activity.approved.includes(files_attachments: :blob).includes(:reviews, :orders)
          activity_data = get_wishlists_and_cart_items("Activity")
          @activity_wishlists = activity_data[:wishlists]
          @activity_cart_items = activity_data[:cart_items]
          @activities = activities._filter_by_category_ids(params[:activity_category_ids]).limit(4)
        end

        def events
          category = ActivityCategory.find_or_create_by(name: 'Events')
          activities = Activity.approved.includes(files_attachments: :blob)
          activity_data = get_wishlists_and_cart_items("Activity")
          @activity_wishlists = activity_data[:wishlists]
          @activity_cart_items = activity_data[:cart_items]
          @activities = activities._filter_by_category_ids([category.id.to_s])
        end

        def show
          @activity = Activity.includes(files_attachments: :blob).friendly.find(params[:id]) rescue nil
          if @activity.nil?
            deepLink = DeepLink.friendly.find(params[:id])&.internal_link || '/'
            render json: { redirectUrl: deepLink }
            return
          end
          query = "entity_type = ? and entity_id = ?", 'Activity', @activity.id
          @is_wishlisted = @wishlists.blank? ? false : @wishlists.where(query).any?
          @added_to_cart = @cart_items.blank? ? false : @cart_items.where(query).any?
          booking_ids = current_customer ? current_customer.bookings.joins(:orders).where(orders: { entity: @activity }).pluck(:id) : []
          @is_booking_completed_if_any = Order.where(booking_id: booking_ids).pluck(:status).include? 'completed'
          @filter_date = params[:filterDate].to_s.present? ? Date.parse(params[:filterDate].to_s) : Date.today
        end

        def homestays
        end

        def cars    
        end

        def ratings
          @reviews = Review.approved.where('entity_id =? and entity_type = ?', params[:entity_id], params[:entity_type]).select(:id, :entity_id, :star)
          render json: @reviews
        end

        def my_rating
          my_rating = Review.approved.where('entity_id =? and entity_type = ? and customer =?', params[:entity_id], params[:entity_type], current_customer.id.to_s).select(:id, :star).first
          render json: my_rating
        end

        def add_rating
          rating = Review.new(customer: current_customer.id.to_s)
          existing_rating = Review.where('entity_type =? and entity_id =? and customer =?', params[:entity_type], params[:entity_id], current_customer.id.to_s).first
          if existing_rating.nil?
            rating.entity_id = params[:entity_id]
            rating.entity_type = params[:entity_type]
          end
          
          if existing_rating.present?
            existing_rating.update(star: params[:star])
          else
            rating.star = params[:star]
            rating.save
          end
          render json: { status: :ok }
        end

        private

        def set_wishlists
          @wishlists = current_customer&.wishlists
        end

        def set_cart_items
          @cart_items = current_customer&.cart&.items
        end


        def get_wishlists_and_cart_items(entity_type)
          wishlists = []
          cart_items = []

          wishlists = @wishlists.where(entity_type: entity_type).pluck(:entity_id) if @wishlists
          cart_items = @cart_items.where(entity_type: entity_type).pluck(:entity_id) if @cart_items

          { wishlists: wishlists, cart_items: cart_items }
        end

      end
    end
  end
end