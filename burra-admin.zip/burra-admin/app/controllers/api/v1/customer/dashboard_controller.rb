module Api
  module V1
    module Customer
      class DashboardController < ApiController
        before_action :set_wishlists_and_cart_items, only: %i[top_activities]

        def top_destinations
          str = 'Goa'
          @locations = Location.includes(image_attachment: :blob).order(Arel.sql("CASE WHEN name LIKE '#{str}%' THEN 0 ELSE 1 END, name"))
        end

        def top_activities
          @activities = Activity.approved.includes(files_attachments: :blob).activities_with_most_positive_reviews_and_orders(true).limit(8)
        end

        def activity_categories
          activity_category_ids = Activity.where(location_id: params[:location_id]).pluck(:activity_category_ids).flatten.uniq
          activity_categories = ActivityCategory.includes(image_attachment: :blob)

          if params[:location_id].present?
            if Location.find_by(id: params[:location_id]).name == 'Goa'
              @activity_categories = activity_categories
            else
              @activity_categories = activity_categories.where(id: activity_category_ids)
            end
          else
            @activity_categories = activity_categories
          end
        end

        def categories_all
          @activity_categories = ActivityCategory.includes(image_attachment: :blob)
          @no_images = params[:images]
        end

        def homestay_categories
          house_categories = HouseCategory.active.joins(rooms: :listing).merge(Room.approved).distinct
          if params[:location_id].present?
            @house_categories = house_categories.where(listing: { location_id: params[:location_id] }).distinct
          else
            @house_categories = house_categories
          end
        end

        def car_types
          car_types = CarType.active.joins(cars: :listing).merge(Car.approved).distinct
          if params[:location_id].present?
            @car_types = car_types.where(listing: { location_id: params[:location_id] }).distinct
          else
            @car_types = car_types
          end
        end

        def homestay_dependents
          @categories = HouseCategory.select(:id, :name).active
          @rules = HouseRule.select(:id, :name).active
          @property_types = PropertyType.select(:id, :name).active
          @amenities = Amenity.select(:id, :name).active
        end

        def car_features
          @fuel_types = CarFuelType.select(:id, :name).active
          @car_types = CarType.select(:id, :name).active
          @transmissions = CarTransmission.select(:id, :name).active
          @car_seats = CarSeat.select(:id, :name).active
        end

        private

        def set_wishlists_and_cart_items
          wishlists = current_customer ? current_customer.wishlists : []
          @activity_wishlists = current_customer ? wishlists.where("entity_type =?", 'Activity').pluck(:entity_id) : []
          @activity_cart_items = []
        end

      end
    end
  end
end
