module Api
  module V1
    module Customer
      class PackageTypesController < ApiController

        def index
          entity_ids = current_customer.cart.items.pluck(:entity_id)
          package_ids = Package.where(entity_id: entity_ids).pluck(:id)
          package_types = PackageType.where(package_id: package_ids)
          render json: package_types
        end

      end
    end
  end
end