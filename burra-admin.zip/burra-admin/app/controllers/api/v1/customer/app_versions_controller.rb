module Api
  module V1
    module Customer
      class AppVersionsController < ApiController
        skip_before_action :authenticate_request!

        def index
          @latest_version = AppVersion.where('app_name =?', 'Burraa').last
          if @latest_version
            render json: @latest_version
          end
        end

      end
    end
  end
end