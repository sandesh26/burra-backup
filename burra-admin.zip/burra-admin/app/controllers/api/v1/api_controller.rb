module Api
  module V1
    class ApiController < ActionController::API
      include ActionController::Helpers
      include ActionController::Caching
      include Response
      # protect_from_forgery prepend: true
      before_action :authenticate_request!
      before_action :set_format
      before_action do
        ActiveStorage::Current.url_options = { protocol: request.protocol, host: request.host, port: request.port }
      end
      
      attr_reader :current_vendor
      attr_reader :current_customer

      private

      def set_format
       request.format = :json  
      end

      protected

      def authenticate_request!
        # binding.pry
        entity_type = params[:controller].split('/')[2]
        klass_name = entity(entity_type)
        # unless phone_or_email_in_token?
        #   render json: { errors: ['Not Authenticated'] }, status: :unauthorized
        #   return
        # end

        if auth_token.present?
          if entity_type == 'customer'
            @current_customer ||= user(klass_name, auth_token[:phone], auth_token[:email])
          else
            @current_vendor ||= user(klass_name, auth_token[:phone], auth_token[:email])
          end
        else
          @current_customer ||= nil
          @current_vendor ||= nil
        end

        # unless @current_customer || @current_vendor
        #   render json: { errors: ['User not found'] }, status: :unauthorized
        #   return
        # end
      # rescue JWT::VerificationError, JWT::DecodeError
      #   render json: { errors: ['Invalid token'] }, status: :unauthorized
      # rescue ActiveRecord::StatementInvalid
      #   render json: { errors: "Invalid statement" }, status: 400
      end

      private
      def http_token
        @http_token ||= if request.headers['Authorization'].present?
          request.headers['Authorization'].split(' ').last
        end
      end

      def auth_token
        @auth_token ||= JsonWebToken.decode(http_token)
      end

      def phone_or_email_in_token?
        http_token && auth_token && (auth_token[:email] || auth_token[:phone].to_i)
      end

      def entity(entity_type)
        _class_name = entity_type.capitalize
        Object.const_get _class_name
      end

      def user(klass_name, phone=nil, email=nil)
        if phone.present?
          klass_name.find_by(phone: phone)
        else
          klass_name.find_by(email: email)
        end
      end

    end
  end
end