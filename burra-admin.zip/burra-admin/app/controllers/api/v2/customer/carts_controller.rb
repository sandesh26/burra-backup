module Api
  module V2
    module Customer
      class CartsController < ApiController

        def items
          @cart = Cart.get_user_cart(params[:userId])
          @cart_items = @cart ? @cart.items.includes(entity: { files_attachments: :blob }) : []
          package_type_ids = @cart.items.pluck(:package_type_id)
          @package_types = PackageType.where(id: package_type_ids)
          @packages = Package.where(id: @package_types.pluck(:package_id)).index_by(&:id)
          @package_types_indexed = @package_types.index_by(&:id)
        end

        def create
          @cart = Cart.get_user_cart(params[:userId])
          cart_items = @cart.items
          @entity = Item.get_entity(params[:entity_id], params[:entity_type])
          selected_date = @entity.start_date.present? ? @entity.start_date : Date.parse(params[:selectedDate])
          selected_slots = params[:quantity].present? ? params[:quantity].to_i : 1

          is_adding_to_cart = true
          available = Item.check_availability(selected_date, @entity, @cart, params[:packageTypeId], selected_slots, is_adding_to_cart)
          success = true

          if available[:response] == true
            selected_slots.times do
              @item = cart_items.build
              @item.entity = @entity
              @item.package_type_id = params[:packageTypeId]
              @item.selected_date = selected_date
              success = @item.save && success
            end
            if success
              render json: { status: :ok }
            else
              render json: { errors: @item.errors.full_messages.to_sentence }
            end
          else
            render json: { errors: available[:pt_message] }
          end
          rescue ActiveRecord::NotNullViolation
            render json: { errors: "null or missing params" }, status: 400
        end

        def item_available
          @cart = Cart.get_user_cart(params[:userId])
          @cart_items = @cart ? @cart.items : []

          errors = {}

          booking_data = params["bookingData"].transform_keys(&:to_sym)
          order_details = booking_data[:orderDetails]

          order_details.each do |entity_id, entities|
            __id = entity_id.split('_')[0]
            entity = Activity.find_by(id: __id)

            entities.each do |index, order|
              date = Date.parse(order[:checkInDate])
              available = Item.check_availability(date, entity, @cart, order[:packageTypeId], order[:quantity].to_i)
              if available[:response] == false
                errors["pt_#{order[:packageTypeId]}"] = available[:pt_message]
              end
            end
          end

          if errors.present?
            render json: { errors: errors }
          else
            render json: { status: :ok }
          end
        end

        def destroy
          @cart = Cart.get_user_cart(params[:userId])
          ActiveRecord::Base.transaction do
            if params[:multiRemove] == '1'
              @cart_items = @cart.items.where(entity_id: params[:entityId], package_type_id: params[:packageTypeId], selected_date: Date.parse(params[:date]))
            else
              @cart_items = @cart.items.where(id: params[:id])
            end
            if @cart_items.length > 0
              @cart_items.delete_all
              render json: { status: :ok }
            else
              render json: { status: :not_found }
            end
          end
        end

      end
    end
  end
end
