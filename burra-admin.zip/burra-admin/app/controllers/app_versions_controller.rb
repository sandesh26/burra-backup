class AppVersionsController < ApplicationController
  before_action :set_app_version, only: %i[ edit update destroy ]

  def index
    @app_versions = AppVersion.page params[:page]
  end

  def new
    @app_version = AppVersion.new
  end

  def edit
  end

  def create
    @app_version = AppVersion.new(app_version_params)

    respond_to do |format|
      if @app_version.save
        format.html { redirect_to app_versions_url, notice: "App version was successfully created." }
      else
        format.html { render :new, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @app_version.update(app_version_params)
        format.html { redirect_to app_versions_url, notice: "App version was successfully updated." }
      else
        format.html { render :edit, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @app_version.destroy!

    respond_to do |format|
      format.html { redirect_to app_versions_url, notice: "App version was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_app_version
      @app_version = AppVersion.find(params[:id])
    end

    def app_version_params
      params.require(:app_version).permit(:app_name, :ios_version, :android_version, :force_update)
    end
end
