class BlogsController < ApplicationController
  before_action :set_blog, only: %i[ show edit update destroy ]
  before_action :blog_categories, only: %i[ new edit update ]

  # GET /blogs or /blogs.json
  def index
    policy_scope(Blog)
    @blogs = Blog.active.includes(:blog_category).order(created_at: :desc).page params[:page]
  end

  def inactive
    @blogs = Blog.inactive.includes(:blog_category).order(created_at: :desc).page params[:page]
  end

  # GET /blogs/1 or /blogs/1.json
  def show
  end

  # GET /blogs/new
  def new
    @blog = Blog.new
  end

  # GET /blogs/1/edit
  def edit
  end

  # POST /blogs or /blogs.json
  def create
    @blog = Blog.new(blog_params)

    respond_to do |format|
      if @blog.save
        NotificationsJob.perform_async('customer', 'Check out our latest Blog Post now!', @blog.title.truncate(100, omission: '...'), 'BlogDetails', @blog.id.to_s)
        format.html { redirect_to blog_url(@blog), notice: "Blog was successfully created." }
        format.json { render :show, status: :created, location: @blog }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @blog.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /blogs/1 or /blogs/1.json
  def update
    authorize @blog
    respond_to do |format|
      if @blog.update(blog_params)
        format.html { redirect_to blog_url(@blog), notice: "Blog was successfully updated." }
        format.json { render :show, status: :ok, location: @blog }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @blog.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /blogs/1 or /blogs/1.json
  def destroy
    authorize @blog
    @blog.destroy!
    # ActionText::RichText
    respond_to do |format|
      format.html { redirect_to blogs_url, notice: "Blog was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_blog
      @blog = Blog.friendly.find(params[:id])
    end

    def blog_categories
      @blog_categories = BlogCategory.order(:title)
    end

    # Only allow a list of trusted parameters through.
    def blog_params
      params.require(:blog).permit(:title, :description, :blog_category_id, :status, :meta_description, :meta_keywords, :meta_title, :is_deleted, :cover_image)
    end
end
