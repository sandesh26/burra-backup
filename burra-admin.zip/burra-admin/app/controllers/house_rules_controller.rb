class HouseRulesController < ApplicationController
  before_action :set_house_rule, only: %i[ show edit update destroy ]

  def index
    @house_rules = HouseRule.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @house_rule = HouseRule.new
  end

  def edit
  end

  def create
    @house_rule = HouseRule.new(house_rule_params)

    respond_to do |format|
      if @house_rule.save
        format.html { redirect_to house_rules_url, notice: "Rule was successfully created." }
        format.json { render :show, status: :created, location: @house_rule }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @house_rule.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @house_rule.update(house_rule_params)
        format.html { redirect_to house_rules_url, notice: "Rule was successfully updated." }
        format.json { render :show, status: :ok, location: @house_rule }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @house_rule.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @house_rule.destroy!

    respond_to do |format|
      format.html { redirect_to house_rules_url, notice: "Rule was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_house_rule
      @house_rule = HouseRule.find(params[:id])
    end

    def house_rule_params
      params.require(:house_rule).permit(:name, :status)
    end
end
