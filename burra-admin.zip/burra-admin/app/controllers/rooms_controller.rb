class RoomsController < ApplicationController
  before_action :set_room, only: %i[ show edit update destroy ]
  before_action :set_list, except: %i[ index ]

  def index
    _rooms = Room.available.order(created_at: :desc)
    if params[:listing_id]
      @rooms = _rooms.where(listing_id: params[:listing_id]).page params[:page]
    else
      @rooms = _rooms.page params[:page]
    end
  end

  def show
    @amenities = Amenity.where(id: @room.amenities).pluck(:name)
    @house_rules = HouseRule.where(id: @room.house_rules).pluck(:name)
  end

  def new
    @room = Room.new
  end

  def edit
  end

  def create
    @room = Room.new(room_params)

    respond_to do |format|
      if @room.save
        format.html { redirect_to listing_room_url(@listing, @room), notice: "Room was successfully created." }
        format.json { render :show, status: :created, location: @room }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @room.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @room.update(room_params.reject { |k| k["files"] })
        if room_params[:files].present?
         room_params[:files].each do |file|
           @room.files.attach(file)
         end
        end
        unless params[:deleted_file_ids].blank?
          files = ActiveStorage::Attachment.where(id: params[:deleted_file_ids])
          files.map(&:purge)
        end
        format.html { redirect_to listing_room_url(@listing, @room), notice: "Room was successfully updated." }
        format.json { render :show, status: :ok, location: @room }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @room.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @room.update!(is_deleted: true)

    respond_to do |format|
      format.html { redirect_back fallback_location: root_path, notice: "Room was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_room
      @room = Room.find_by(id: params[:id])
    end

    def set_list
      @listing = Listing.find_by(id: params[:listing_id])
      @categories = HouseCategory.order(created_at: :desc)
      @property_types = PropertyType.order(created_at: :desc)
      @house_rules = HouseRule.order(created_at: :desc)
      @amenities = Amenity.order(created_at: :desc)
    end

    def room_params
      params.require(:room).permit(:name, :description, :bedrooms, :bathrooms, :balcony, :status, :type_of_bed, :min_guest_occupancy, :max_guest_occupancy, :size, :actual_price, :discounted_price, :floor_level, :listing_id, :is_deleted, :house_category_id, :property_type_id, house_rules: [], amenities: [], :files => [])
    end
end