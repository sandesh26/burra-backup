class ActivityCategoriesController < ApplicationController
  before_action :set_activity_category, only: %i[ show edit update destroy ]

  def index
    policy_scope(ActivityCategory)
    @activity_categories = ActivityCategory.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @activity_category = ActivityCategory.new
  end

  def edit
  end

  def create
    @activity_category = ActivityCategory.new(activity_category_params)
    authorize @activity_category

    respond_to do |format|
      if @activity_category.save
        format.html { redirect_to activity_categories_url, notice: "Activity category was successfully created." }
        format.json { render :show, status: :created, location: @activity_category }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @activity_category.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    authorize @activity_category
    respond_to do |format|
      if @activity_category.update(activity_category_params)
        format.html { redirect_to activity_categories_url, notice: "Activity category was successfully updated." }
        format.json { render :show, status: :ok, location: @activity_category }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @activity_category.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    authorize @activity_category
    @activity_category.delete

    respond_to do |format|
      format.html { redirect_to activity_categories_url, notice: "Activity category was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_activity_category
      @activity_category = ActivityCategory.find(params[:id])
    end

    def activity_category_params
      params.require(:activity_category).permit(:name, :status, :image)
    end
end
