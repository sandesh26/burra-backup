class AmenitiesController < ApplicationController
  before_action :set_amenity, only: %i[ show edit update destroy ]

  def index
    @amenities = Amenity.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @amenity = Amenity.new
  end

  def edit
  end

  def create
    @amenity = Amenity.new(amenity_params)

    respond_to do |format|
      if @amenity.save
        format.html { redirect_to amenities_url, notice: "Amenity was successfully created." }
        format.json { render :show, status: :created, location: @amenity }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @amenity.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @amenity.update(amenity_params)
        format.html { redirect_to amenities_url, notice: "Amenity was successfully updated." }
        format.json { render :show, status: :ok, location: @amenity }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @amenity.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @amenity.destroy!

    respond_to do |format|
      format.html { redirect_to amenities_url, notice: "Amenity was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    def set_amenity
      @amenity = Amenity.find(params[:id])
    end

    def amenity_params
      params.require(:amenity).permit(:name, :status)
    end
end
