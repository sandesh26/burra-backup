class DashboardController < ApplicationController
  include BookingsHelper

  def index
    authorize self
    @pending_listings_count = Activity.pending.length
    orders = Order.not_canceled.not_initiated
    @orders_count = orders.where(created_at: Time.zone.now.beginning_of_day..Time.zone.now.end_of_day).length
    @earnings_monthly = orders.where("extract(year from created_at) = ? AND extract(month from created_at) = ?", Date.today.year, Date.today.month).sum(:earned_amt)
    @earnings_yearly = orders.where("extract(year from created_at) = ?", Date.today.year).sum(:earned_amt)
    today_earnings = orders.where("DATE(created_at) = ?", Date.today).sum(:earned_amt)
    @pie_chart = [@earnings_monthly, today_earnings]
    @monthly_earnings_data = get_monthly_chart_data(orders).map { |item| item[:earnings] }
    # binding.pry

    # channel_name = "booking_channel"

    # ActionCable.server.broadcast channel_name, { order: Order.last }
  end
end