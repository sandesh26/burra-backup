class AdminUsersController < ApplicationController
  before_action :set_admin_user, only: %i[ show edit update destroy ]
  before_action :set_roles, only: %i[ create new edit update destroy ]

  def index
    policy_scope(User)
    role_id = Role.find_by(name: 'super_admin')
    @admin_users = User.where.not(role_id: role_id).order(:name).page params[:page]
  end

  def show
  end

  def new
    @admin_user = User.new
    authorize @admin_user
  end

  def edit
  end

  def create
    @admin_user = User.new(admin_user_params)
    authorize @admin_user
    respond_to do |format|
      if @admin_user.save
        format.html { redirect_to admin_users_url, notice: "User was successfully created." }
        format.json { render :show, status: :created, location: @admin_user }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @admin_user.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    authorize @admin_user
    respond_to do |format|
      if @admin_user.update(admin_user_params)
        format.html { redirect_to admin_users_url, notice: "User was successfully updated." }
        format.json { render :show, status: :ok, location: @admin_user }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @admin_user.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    authorize @admin_user
    @admin_user.destroy!

    respond_to do |format|
      format.html { redirect_to admin_users_url, notice: "User was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private
    def set_admin_user
      @admin_user = User.find(params[:id])
    end

    def set_roles
      @roles = Role.where.not(name: 'super_admin').order(:name)
    end

    def admin_user_params
      params.require(:user).permit(:name, :email, :role_id, :status, :password, :password_confirmation)
    end
end
