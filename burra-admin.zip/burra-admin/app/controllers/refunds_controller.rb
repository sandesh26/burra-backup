class RefundsController < ApplicationController
  # before_action :set_refund, only: %i[ show edit update destroy ]

  def index
    policy_scope(Refund)
    @refunds = Refund.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @refund = Refund.new
  end

  def edit
  end

  def create
    @refund = Refund.new(refund_params)

    respond_to do |format|
      if @refund.save
        format.html { redirect_to refund_url(@refund), notice: "Refund was successfully created." }
        format.json { render :show, status: :created, location: @refund }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @refund.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @refund.update(refund_params)
        format.html { redirect_to refund_url(@refund), notice: "Refund was successfully updated." }
        format.json { render :show, status: :ok, location: @refund }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @refund.errors, status: :unprocessable_entity }
      end
    end
  end

  private
    def set_refund
      @refund = Refund.find(params[:id])
    end

    def refund_params
      params.require(:refund).permit(:r_id, :amount, :payment_id, :status, :order_id)
    end
end
