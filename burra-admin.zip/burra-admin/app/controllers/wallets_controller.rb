class WalletsController < ApplicationController
  include WalletHelper
  before_action :set_wallet, only: %i[ show edit update transactions ]
  before_action :get_customers, only: %i[ new create edit update ]

  def customers
    policy_scope(Wallet)
    @wallets = Wallet.customer_wallet.includes(:entity).order(:balance).page params[:page]
  end

  def vendors
    policy_scope(Wallet)
    @wallets = Wallet.vendor_wallet.includes(:entity).order(:balance).page params[:page]
  end

  def show
  end

  def new
    @wallet = Wallet.new
  end

  def edit
    @bank_accounts = []
    if @wallet.entity_type == 'Vendor'
      @bank_accounts = @wallet.entity.account_details
    end
  end

  def transactions
    @transactions = @wallet.transactions.order(:amount).page params[:page]
  end

  def create
    @wallet = Wallet.new
    wallet_params = params[:wallet]
    entity = Customer.find_by(id: wallet_params[:entity_id])
    @wallet.entity = entity
    @wallet.balance = wallet_params[:balance].to_i

    respond_to do |format|
      if @wallet.save
        @wallet.create_transaction('add', wallet_params[:balance].to_i)
        format.html { redirect_to vendors_wallets_url, notice: "Wallet was successfully created." }
        format.json { render :show, status: :created, location: @wallet }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @wallet.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    wallet_params = params[:wallet]
    changed_balance = wallet_params[:balance].to_i
    if wallet_params[:transaction_type] == 'add'
      @wallet.balance += changed_balance
    else
      @wallet.balance -= changed_balance
    end
    respond_to do |format|
      if @wallet.save
        @wallet.create_transaction(wallet_params[:transaction_type], changed_balance)
        format.html { redirect_to back_url(request.referrer, params[:wallet][:entity_type].downcase), notice: "Wallet was successfully updated." }
        format.json { render :show, status: :ok, location: @wallet }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @wallet.errors, status: :unprocessable_entity }
      end
    end
  end

  private
    def set_wallet
      @wallet = Wallet.find_by(id: params[:id])
    end

    def get_customers
      # @customers = Customer.all
      @customers = []
    end
end
