class CartsController < ApplicationController
  def show
    @cart = Cart.find_by(customer_id: params[:customer_id])
    @cart_items = @cart.items
  end
end
