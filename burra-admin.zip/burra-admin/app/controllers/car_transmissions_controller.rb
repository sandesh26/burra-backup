class CarTransmissionsController < ApplicationController
  before_action :set_car_transmission, only: %i[ show edit update destroy ]

  def index
    @car_transmissions = CarTransmission.order(created_at: :desc).page params[:page]
  end

  def show
  end

  def new
    @car_transmission = CarTransmission.new
  end

  def edit
  end

  def create
    @car_transmission = CarTransmission.new(car_transmission_params)

    respond_to do |format|
      if @car_transmission.save
        format.html { redirect_to car_transmissions_url, notice: "Transmission was successfully created." }
        format.json { render :show, status: :created, location: @car_transmission }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @car_transmission.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @car_transmission.update(car_transmission_params)
        format.html { redirect_to car_transmissions_url, notice: "Transmission was successfully updated." }
        format.json { render :show, status: :ok, location: @car_transmission }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @car_transmission.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @car_transmission.destroy!

    respond_to do |format|
      format.html { redirect_to car_transmissions_url, notice: "Transmission was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    def set_car_transmission
      @car_transmission = CarTransmission.find(params[:id])
    end

    def car_transmission_params
      params.require(:car_transmission).permit(:name, :status)
    end
end
