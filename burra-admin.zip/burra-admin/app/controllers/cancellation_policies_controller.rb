class CancellationPoliciesController < ApplicationController
  before_action :set_cancellation_policy
  def index
    if @cancellation_policy.nil?
      @cancellation_policy = CancellationPolicy.create(content: '')
      redirect_to edit_cancellation_policy_path(@cancellation_policy)
    else
      render :index
    end
  end

  def edit
  end

  def update
    authorize @cancellation_policy
    @cancellation_policy.update(cancellation_policy_params)
    @cancellation_policy.save
    redirect_to cancellation_policies_path, notice: 'Cancellation Policy updated!'
  end

  private

  def set_cancellation_policy
    @cancellation_policy = CancellationPolicy.first
  end

  def cancellation_policy_params
    params.require(:cancellation_policy).permit(:content)
  end
end
