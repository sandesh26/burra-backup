// Entry point for the build script in your package.json
import "@hotwired/turbo-rails"
import "./controllers"
// import "./channels"
import * as bootstrap from "bootstrap"
import 'datatables.net'
import './add_jquery'
import './sb-admin'
import './jquery.easing.min'
import './bootstrap.bundle.min'
import './jquery.dataTables.min'
import './dataTables.bootstrap4.min'
import 'trix'
import '@rails/actiontext'
import SlimSelect from './slimselect.min'
import './Chart.min'
import '@nathanvda/cocoon'

// $(document).ready(function(){
//   if (location.pathname === '/') {
//     dashboardChart();
//   }
// });
//
// $(document).on('cocoon:before-remove', '.types-nested-fields', function(event, removedItem) {
//   debugger
//   removedItem.addClass('marked-for-removal');
// });
//
// $(document).on('click', '.remove-package-types', function() {
//   debugger
//   $(this).closest('.types-nested-fields').remove();
// });

var dataTable = null;
$(document).on('turbo:load', function() {
  if (location.pathname === '/') {
    dashboardChart();
  }
  dataTable = $('#dataTable').dataTable({
    "order": [[0, 'desc']],
    "ordering": false,
    "bProcessing": true,
    "bPaginate": false,
    "bInfo": false,
    "bFilter": false,
    "bDestroy": true,
  })
  new SlimSelect({
    select: '#slimSelect'
  })
  new SlimSelect({
    select: '#slimSelect1'
  })
  new SlimSelect({
    select: '#slimSelect2'
  })
  new SlimSelect({
    select: '#multiSelect',
    settings: {
      placeholderText: 'Select amenities',
    }
  })
  new SlimSelect({
    select: '#multiSelect1',
    settings: {
      placeholderText: 'Select rules',
    }
  })
})


document.addEventListener("trix-file-accept", function(event) {
  event.preventDefault()
  alert("File attachment not supported!")
})

document.addEventListener("turbo:before-render", function(event) {
  if (dataTable !== null) {
   dataTable.fnDestroy();
   // dataTable.empty();
   dataTable = null;
  }
});

$(document).on("click", "#clearAuditsSearchParams", function(event) {
  event.preventDefault();
  Turbo.visit('/audits');
});


$(document).on('turbo:render', function(event) {
  event.preventDefault();
  new SlimSelect({
    select: '#slimSelect'
  })
  new SlimSelect({
    select: '#slimSelect1'
  })
  new SlimSelect({
    select: '#slimSelect2'
  })
  new SlimSelect({
    select: '#multiSelect',
    settings: {
      placeholderText: 'Select amenities',
    }
  })
  new SlimSelect({
    select: '#multiSelect1',
    settings: {
      placeholderText: 'Select rules',
    }
  })
});
