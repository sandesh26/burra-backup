class RegisterActivityJob < ApplicationJob
  queue_as :default

  def perform(params, vendor)
    ActiveRecord::Base.transaction do
      # category = ListingCategory.find_or_create_by(name: params[:category][:name])
      if params[:profile] && params[:profile] != 'null' && params[:profile][:documentId]
        vendor.documentid.attach(params[:profile][:documentId])
        vendor.license.attach(params[:profile][:license])
        vendor.document_type = params[:profile][:documentType]
        vendor.save
      end
      register_payload(params, vendor)
    end
  end

  def register_payload(params, vendor)
    add_activities(params[:activity], params[:account_details], vendor)
    # case category.name
    # when 'Activities'
    #   add_activities(params[:activity], params[:account_details], vendor)
    # when 'Renting Vehicles'
    #   add_cars(params[:vehicle], vendor)
    # when 'Homestays'
    #   add_homestays(params[:room], params[:property], vendor)
    # end
  end

  private

  def add_activities(activity_params, account_params, vendor)
    location = Location.find_or_create_by(name: 'Goa')
    activity_params.each do |key, value|
      activity = Activity.new(
        name: value['name'],
        description: value['description'],
        min_person_allowed: value['minPersonAllowed'],
        max_person_allowed: value['maxPersonAllowed'],
        activity_category_ids: value['activityTypes'].values.map { |inner_hash| inner_hash.values.join }.map(&:to_i).map(&:to_s),
        vendor_price: value['price'],
        start_date: value['startDate'].present? ? Date.parse(value['startDate']) : nil,
        start_time: value['startTime'],
        end_time: value['endTime'],
        address: value['address'],
        latitude: value['latitude'],
        longitude: value['longitude'],
        meta_title: value['metaTitle'],
        meta_description: value['metaDescription'],
        meta_keywords: value['metaKeywords'],
        vendor: vendor,
        location_id: location.id
      )
      add_media_files(activity, value['media'])
      add_account_details(account_params, activity, vendor)
    end
  end

  def add_cars(car_params, listing)
    car_params.each do |key, value|
      car = Car.new(
        name: value['name'],
        description: value['description'],
        car_type_id: value['carType'],
        car_seat_id: value['seats'],
        car_fuel_type_id: value['fuelType'],
        car_transmission_id: value['transmission'],
        actual_price: value['actualPrice'],
        discounted_price: value['discountedPrice'],
        listing: listing
      )
      add_media_files(car, value['media'])
      car.save
    end
  end

  def add_homestays(room_params, property_params, listing)
    amenities = property_params[:amenities]
    house_rules = property_params[:houseRules]
    room_params.each do |key, value|
      room = Room.new(
        bedrooms: value['bedrooms'],
        bathrooms: value['bathrooms'],
        balcony: value['balcony'],
        type_of_bed: value['bedType'],
        min_guest_occupancy: value['minOccupancy'],
        max_guest_occupancy: value['maxOccupancy'],
        name: value['name'],
        description: value['description'],
        size: value['size'],
        actual_price: value['actualPrice'],
        discounted_price: value['discountedPrice'],
        floor_level: value['floorLevel'],
        amenities: JSON.parse(amenities) || [],
        house_rules: JSON.parse(house_rules) || [],
        property_type_id: property_params[:propertyType],
        house_category_id: property_params[:houseCategory],
        listing: listing
      )
      add_media_files(room, value['media'])
      room.save
    end
  end

  def add_account_details(account_params, activity, vendor)
    if account_params[:bankAccountId].present?
      activity.account_detail_id = account_params[:bankAccountId]
    else
      existing_acc = AccountDetail.where('vendor_id =? and account_number=?', vendor.id, account_params[:bankAccNumber])
      if existing_acc.blank?
        bank_info = AccountDetail.create(
        acc_holder_name: "#{account_params[:firstName]} #{account_params[:lastName]}".strip,
        email_id: account_params[:email],
        phone_number: account_params[:mobileNumber],
        gst_number: account_params[:gstNumber],
        account_number: account_params[:bankAccNumber],
        ifsc_code: account_params[:ifsc],
        bank_name: account_params[:bankName],
        vendor: vendor
        )
        activity.account_detail_id = bank_info.id
      end
    end
    activity.save
  end

  def add_media_files(model, files)
    files.each do |k, v|
      model.files.attach(v)
    end
  end
end
