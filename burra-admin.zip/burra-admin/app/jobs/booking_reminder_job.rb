class BookingReminderJob < ApplicationJob

  def perform(booking_id)
    booking = Booking.find_by(id: booking_id)
    return if booking.nil?
    
    booking.orders.each do |order|
      CustomerMailer.with(order: order).booking_reminder_email.deliver_now
      Notification.new(booking.customer.device_tokens.pluck(:token).compact.uniq, 'Booking Reminder!', "#{order.entity.name.truncate(100, omission: '...')}\n#{order.check_in_date.strftime("%a, %d %b %Y")}").send_notification
    end
  end
end