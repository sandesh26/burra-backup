class UploadFileJob < ApplicationJob
  queue_as :default

  def perform(listing, files)
    listing.files.attach(files)
    listing.save
  end
end
