class DeleteAccountJob < ApplicationJob
  queue_as :default

  def perform(activity_ids)
    Activity.where(id: activity_ids).update_all(is_deleted: true)
    Order.where(entity_id: activity_ids).update_all(status: 'canceled')
    Complaint.where(entity_id: activity_ids).update_all(status: 'deleted')
    Review.where(entity_id: activity_ids).delete_all
    Wishlist.where(entity_id: activity_ids).delete_all
    Item.where(entity_id: activity_ids).delete_all
  end
end