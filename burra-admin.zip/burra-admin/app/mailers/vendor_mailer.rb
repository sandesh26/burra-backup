class VendorMailer < ApplicationMailer
	default from: Rails.application.credentials.EMAIL_USERNAME

	def booking_received_email
  	@order = params[:order]
  	@booking = @order.present? ? @order.booking : nil
  	if @booking && @order && @order.vendor&.email
	  	@customer = @booking.customer
	  	@email = @order.vendor.email
    	mail(to: @email, from: "Burraa <#{Rails.application.credentials.EMAIL_USERNAME}>", subject: 'Booking Received')
	  end
	end
end
