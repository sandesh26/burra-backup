class CustomerMailer < ApplicationMailer
  default from: Rails.application.credentials.EMAIL_USERNAME

  def reset_password_email
    @user = params[:user]
    mail(to: @user.email, subject: 'Verification code')
  end

  def changed_password_email
    @user = params[:user]
    mail(to: @user.email, subject: 'Password changed')
  end

  def send_verification_code
    @customer = params[:customer]
    if @customer && @customer.email
      mail(to: @customer.email, from: "One Time Password <#{Rails.application.credentials.EMAIL_USERNAME}>", subject: 'Verification code')
    end
  end

  def booking_confirmation_email
    @order = params[:order]
    @booking = @order.present? ? @order.booking : nil
    if @booking && @booking.email
      @email = @booking.email
      attachments[@order.qrcode.filename.to_s] = @order.qrcode.download
      mail(to: @email, from: "Burraa <#{Rails.application.credentials.EMAIL_USERNAME}>", subject: 'Booking Confirmed')
    end
  end

  def booking_reminder_email
    @order = params[:order]
    @booking = @order.present? ? @order.booking : nil
    if @booking && @booking.email
      @email = @booking.email
      attachments[@order.qrcode.filename.to_s] = @order.qrcode.download
      mail(to: @email, from: "Burraa <#{Rails.application.credentials.EMAIL_USERNAME}>", subject: 'Booking Reminder')
    end
  end
end
