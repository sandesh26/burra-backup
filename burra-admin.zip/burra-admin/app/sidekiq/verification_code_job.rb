class VerificationCodeJob
  include Sidekiq::Job
  sidekiq_options retry: 2

  def perform(customer_id)
    klass = Object.const_get 'Customer'
    customer = klass.find_by(id: customer_id)
    CustomerMailer.with(customer: customer).send_verification_code.deliver_now
  end
end
