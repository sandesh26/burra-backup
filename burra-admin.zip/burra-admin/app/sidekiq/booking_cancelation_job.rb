class BookingCancelationJob
  include Sidekiq::Job
  sidekiq_options retry: 1

  def perform(id)
    cancelation = Cancelation.find_by(id: id)
    order = cancelation.order
    order.update(status: 'canceled')
    payment_id = order.booking.payment_id
    refund_amt = cancelation.refund_amt

    customer = order.booking.customer
    vendor = order.vendor
    c_device_tokens = customer.device_tokens.pluck(:token).compact.uniq
    v_device_tokens = vendor.device_tokens.pluck(:token).compact.uniq
    
    title = "Booking Canceled# #{order.entity_booking_id}"
    c_body = "Your Booking for '#{order.entity.name.truncate(50, omission: '...')}' has been canceled as requested. A refund has been initiated.\nYou should see funds in your source account within 5-7 working days.\nContact us for assistance.\nThanks for choosing Burraa."
    v_body = "A Booking has been canceled for '#{order.entity.name.truncate(50, omission: '...')}'"
    # CustomerMailer.with(booking_id: booking_id).booking_confirmation_email.deliver_later
    # VendorMailer.with(booking_id: booking_id).booking_received_email.deliver_later
    # Notification.new(c_device_tokens, title, c_body).send_notification
    # Notification.new(v_device_tokens, title, v_body).send_notification

    # Initiate Refund
    # response = Razorpay.new.initiate_refund(payment_id, refund_amt)
    # Phonepe.new.refund(cancelation, customer, refund_amt, payment_id)
    # Refund.create(r_id: response["id"], amount: refund_amt, payment_id: payment_id, status: response["status"], order_id: order.id)
  end
end
