class NotificationsJob
  include Sidekiq::Job
  sidekiq_options retry: 2

  BATCH_SIZE = 100 

  def perform(user_type, title, body, route_name=nil, action_id=nil, screen_name=nil)
    _class_name = user_type.capitalize
    device_tokens = DeviceToken.where(client_type: _class_name).pluck(:token).compact.uniq
    
    device_tokens.each_slice(BATCH_SIZE) do |batch|
      Notification.new(batch, title, body, route_name, action_id, screen_name).send_notification
    end
  end
end