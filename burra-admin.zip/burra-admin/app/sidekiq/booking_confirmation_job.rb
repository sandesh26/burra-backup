class BookingConfirmationJob
  include Sidekiq::Job
  sidekiq_options retry: 2
  # sidekiq_options retry: 10, retry_queue: 'low'

  def perform(id, email_only = false)
    booking = Booking.find_by(id: id)
    
    if booking.nil?
      Rails.logger.error("Booking with id #{id} not found. Job aborted.")
      return
    end
    
    booking.orders.includes(:order_items).each do |order|
      entity = order.entity
      vendor = order.vendor

      begin
        VendorMailer.with(order: order).booking_received_email.deliver_now unless email_only
        CustomerMailer.with(order: order).booking_confirmation_email.deliver_now
      rescue => e
        Rails.logger.error("Failed to send email for order ##{order.id}: #{e.message}")
      end

      begin
        Notification.new(vendor.device_tokens.pluck(:token).compact.uniq, 'New Booking Received!', "#{entity.name.truncate(100, omission: '...')}\n#{order.check_in_date.strftime("%a, %d %b %Y")}").send_notification unless email_only
        Notification.new(booking.customer.device_tokens.pluck(:token).compact.uniq, 'Booking Confirmed!', "#{entity.name.truncate(100, omission: '...')}\n#{order.check_in_date.strftime("%a, %d %b %Y")}").send_notification
      rescue => e
        Rails.logger.error("Failed to send notification for order ##{order.id}: #{e.message}")
      end
    end
  end
end
