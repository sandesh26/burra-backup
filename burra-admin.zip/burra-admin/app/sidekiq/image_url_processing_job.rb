class ImageUrlProcessingJob
  include Sidekiq::Job

  def perform(image_ids, _class_name, record_id, protocol, host, port)
    # ActiveStorage::Current.url_options = { protocol: protocol, host: host, port: port }
    # klass = Object.const_get _class_name
    # image_urls = []
    # image_ids.each do |image_id|
    #   image = ActiveStorage::Attachment.find_by(id: image_id)
    #   image_url = image.url
    #   image_urls << image_url
    # end
    # klass.find_by(id: record_id).update(images: image_urls)
  end
end
