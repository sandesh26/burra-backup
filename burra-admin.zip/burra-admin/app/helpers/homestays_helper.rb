module HomestaysHelper
end
