module BookingsHelper

  def get_hourly_data(booking_orders)
    start_of_day = (Time.now.beginning_of_day)
    end_of_day = (Time.now.end_of_day)
    booking_orders.where(created_at: start_of_day..end_of_day).map { |booking_order| { date: booking_order.created_at.strftime("%I:%M"), earnings: format_value_in_k(booking_order.earned_amt) } }
  end

  def get_weekly_data(booking_orders)
    weekly_data = booking_orders.group_by { |booking_order| booking_order.created_at.beginning_of_week.to_date.cweek }
    weekly_data_with_total_price = weekly_data.map do |week, booking_orders|
      total_price = booking_orders.map{|o| o.earned_amt}.sum
      { date: week, earnings: format_value_in_k(total_price) }
    end
  end


  def get_monthly_data(booking_orders)
    monthly_data = booking_orders.group_by { |booking_order| booking_order.created_at.strftime("%b") }
    monthly_data_with_total_price = monthly_data.map do |month, booking_orders|
      total_price = booking_orders.map{|o| o.earned_amt}.sum
      { date: month, earnings: format_value_in_k(total_price) }
    end
  end

  def get_monthly_chart_data(booking_orders)
    monthly_data = booking_orders.group_by { |booking_order| booking_order.created_at.strftime("%b") }

    all_months_data = {}

    Date::MONTHNAMES.compact.each do |month_name|
      month_abbr = Date.parse(month_name).strftime("%b")
      if monthly_data[month_abbr].present?
        total_price = monthly_data[month_abbr].map { |o| o.earned_amt }.sum
        all_months_data[month_abbr] = total_price
      else
        all_months_data[month_abbr] = 0
      end
    end

    all_months_data.map { |month, earnings| { date: month, earnings: earnings } }
  end

  def format_value_in_k(value)
    if value >= 1000
      (value.to_f / 1000).round(1)
    else
      value
    end
  end

end