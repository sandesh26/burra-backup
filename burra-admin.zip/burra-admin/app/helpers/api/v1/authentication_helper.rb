module Api::V1::AuthenticationHelper
end
