module ListingsHelper
  def status_action_link(entity, status)
    case status
    when 'created'
      link_to_submit_verification(entity)
    when 'submitted'
      link_to_submit_approval(entity)
    end
  end

  private

  def link_to_submit_verification(entity)
    link_to(
      "Submit for verification",
      entity_path(entity, "#{entity.class.name.downcase}": { status: 'submitted' }),
      data: { "turbo-method": :put },
      class: "float-right text-white d-none d-sm-inline-block btn btn-sm #{badge_bg_color(entity.status)} shadow-sm"
    )
  end

  def link_to_submit_approval(entity)
    link_to(
      "Submit for approval",
      entity_path(entity, "#{entity.class.name.downcase}": { status: 'approved' }),
      data: { "turbo-method": :put },
      class: "float-right text-white d-none d-sm-inline-block btn btn-sm #{badge_bg_color(entity.status)} shadow-sm"
    )
  end

  def entity_path(entity, options = {})
    send("#{entity.class.name.downcase}_path", entity, options)
  end
end
