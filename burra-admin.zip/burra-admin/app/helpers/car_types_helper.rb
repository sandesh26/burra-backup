module CarTypesHelper
end
