module ApplicationHelper

  LISTING_PATHS = ['/cars', '/rooms', '/activities']
  BLOG_PATHS = ['/blogs', '/blog_categories', '/blogs/inactive']
  NOTIFICATIONS_PATHS = ['/app_notifications', '/app_notifications/customer', '/app_notifications/vendor']
  ACTIVITIES_PATHS = ['/activities', '/activity_categories']
  WALLETS_PATHS = ['/wallets', '/wallet', '/transactions']
  HOMESTAYS_PATHS = ['/rooms', '/house_categories', '/house_rules', '/amenities', '/property_types']
  RENTING_VEHICLES_PATH = ['/cars', '/car_types', '/car_transmissions', '/car_fuel_types', '/car_seats']

  def listing_active?(class_name)
    _class_name = 'collapsed'
    current_path = url_for(only_path: true)
    if LISTING_PATHS.any? { |i| current_path.include?(i)}
      _class_name = class_name
    end
    _class_name
  end

  def blogs_active?(class_name)
    _class_name = 'collapsed'
    current_path = url_for(only_path: true)
    if BLOG_PATHS.any? { |i| current_path.include?(i)}
      _class_name = class_name
    end
    _class_name
  end

  def notification_active?(class_name)
    _class_name = 'collapsed'
    current_path = url_for(only_path: true)
    if NOTIFICATIONS_PATHS.any? { |i| current_path.include?(i)}
      _class_name = class_name
    end
    _class_name
  end

  def activity_sub_active?(class_name)
    _class_name = 'collapsed'
    current_path = url_for(only_path: true)
    if ACTIVITIES_PATHS.any? { |i| current_path.include?(i)}
      _class_name = class_name
    end
    _class_name
  end

  def wallets_active?(class_name)
    _class_name = 'collapsed'
    current_path = url_for(only_path: true)
    if WALLETS_PATHS.any? { |i| current_path.include?(i)}
      _class_name = class_name
    end
    _class_name
  end

  def homestay_active?(class_name)
    _class_name = 'collapsed'
    current_path = url_for(only_path: true)
    if HOMESTAYS_PATHS.any? { |i| current_path.include?(i)}
      _class_name = class_name
    end
    _class_name
  end

  def renting_vehicle_active?(class_name)
     _class_name = 'collapsed'
    current_path = url_for(only_path: true)
    if RENTING_VEHICLES_PATH.any? { |i| current_path.include?(i)}
      _class_name = class_name
    end
    _class_name
  end

  def badge_bg_color(status)
    case status
    when 'created'
      'bg-secondary'
    when 'confirmed'
      'bg-success'
    when 'submitted'
      'bg-primary'
    when 'approved'
      'bg-info'
    when 'rejected'
      'bg-warning'
    when 'suspended'
      'bg-danger'
    else
      'bg-secondary'
    end
  end

  def time_format(time_str)
    time_obj = Time.parse(time_str)
    time_obj.strftime("%I:%M %p")
  end

end
