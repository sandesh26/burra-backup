module WalletHelper

	def back_url(ref, type)
		if type == 'vendor'
			vendors_wallets_url
		elsif type == 'customer'
			customers_wallets_url
		else
			ref
		end	
	end

end
