module HouseRulesHelper
end
