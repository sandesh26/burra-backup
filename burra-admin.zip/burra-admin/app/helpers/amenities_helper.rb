module AmenitiesHelper
end
